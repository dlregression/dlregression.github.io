import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

class KL_Loss(nn.Module):
    def __init__(self, lamb):
        super(KL_Loss, self).__init__()
        self.lamb = lamb
        self.origin = True

    def forward(self, input: Tensor, target: Tensor, input_orig: Tensor) -> Tensor:
        prob = F.softmax(input)
        prob_orig = F.softmax(input_orig)
        loss = F.cross_entropy(input, target) + self.lamb * F.kl_div(torch.log(prob + 1e-10), prob_orig + 1e-10, reduce='mean')
        return loss

class KL_DIV(nn.Module):
    def __init__(self, t) -> None:
        super(KL_DIV, self).__init__()
        self.t = t
    
    def forward(self, h1_x, h2_x):
        h1_log_p = F.log_softmax(h1_x / self.t)
        h2_log_p = F.log_softmax(h2_x / self.t)
        return F.kl_div(h2_log_p, h1_log_p, reduce='mean', log_target=True)

def CrossEntropyLoss(**kwargs):
    return torch.nn.CrossEntropyLoss(**kwargs)