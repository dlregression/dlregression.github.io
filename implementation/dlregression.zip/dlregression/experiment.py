import os
import sys
from typing import OrderedDict
import yaml
import experiments
from itertools import product
from easydict import EasyDict
from utils import ProgressBar

class Experiment:
    def __init__(self, env, config = None) -> None:
        self.config = EasyDict()
        self.env = env
        if config is not None:
            self.load_config(config)

    def load_config(self, config):
        config = config.replace('\\', '/')
        path = os.path.join(self.env.config_root, f'{config}.yml')
        with open(path, 'r') as f:
            self.config = EasyDict(yaml.safe_load(f))
            self.config.name = config

    def iter_vars(self):
        if 'iter_vars' not in self.config:
            return [{}]
        names = []
        values = []
        for var in self.config.iter_vars:
            names.append(var.name)
            values.append(var.values)
        for tup in product(*values):
            vars = OrderedDict()
            for i in range(len(names)):
                vars[names[i]] = tup[i]
            yield vars

    def do(self):
        for exp in self.each_exp():
            exp.do_it()

    def each_exp(self):
        for index in range(self.config.repeat):
            for vars in self.iter_vars():
                exp = Exp(self.env, self.config, vars, index)
                yield exp

def config_apply_vars(config, vars):
    context = yaml.dump(config)
    for name, value in vars.items():
        context = context.replace(f'?{name}?', str(value))
    cfg = yaml.load(context, Loader=yaml.Loader)
    return cfg

class Exp:
    def __init__(self, env, config, vars, tag) -> None:
        self.env = env
        self.config = config_apply_vars(config, vars)
        self.id = '.'.join([str(var) for var in vars.values()] + [str(tag)])
        self.exp_dir = os.path.join(env.output_root, config.name)
        if not os.path.exists(self.exp_dir):
            os.makedirs(self.exp_dir)
        self.info = {}

    def do_it(self):
        progress_bar = ProgressBar('Main')
        progress_bar.reset(len(self.config.pipelines))
        for phase in self.config.pipelines:
            name = phase.name
            progress_bar.set_description(f'Phase {name}')
            if 'args' in phase:
                kwargs = phase.args
            else:
                kwargs = {}
            func = getattr(experiments, name)
            func(self, **kwargs)
            progress_bar.update()

def list_exp(env, config):
    path = os.path.join(env.config_root, config)
    config_list = []
    if os.path.isdir(path):
        for dirpath, dirnames, files in os.walk(path):
            for file_name in files:
                config, ext_name = os.path.splitext(file_name)
                config = os.path.join(dirpath, config)
                if ext_name == '.yml' or ext_name == '.yaml':
                    config = os.path.relpath(config, env.config_root)
                    config_list.append(Experiment(env, config))
    else:
        config_list.append(Experiment(env, config))
    return config_list