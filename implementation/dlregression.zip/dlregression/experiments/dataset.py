import os
import datasets
import adversarials
import utils
import torch
import pandas as pd
from torchvision.utils import make_grid, save_image
from itertools import product
from torch._utils import _accumulate
from utils import ProgressBar
from . import private as P
from .metric import calc_metric

__all__ = ['load_dataset', 'adversarial_dataset', 'visual_dataset', 'synthesize_dataset', 'concat_dataset', 'split_dataset', 'prioritize_dataset', 'count_dataset_labels']

def load_dataset(exp, dataset_name, train_transforms=[], test_transforms=[], target_transforms=[], **kwargs):
    ds = getattr(datasets, dataset_name)
    path = os.path.join(exp.env.dataset_root, dataset_name)
    if not os.path.exists(path):
        os.makedirs(path)
    train_transforms = _get_transform(train_transforms)
    test_transforms = _get_transform(test_transforms)
    target_transforms = _get_transform(target_transforms)
    dataset, classes = ds(path, **kwargs)
    P._ds_init(exp, dataset, classes, train_transforms, test_transforms, target_transforms)

def adversarial_dataset(exp, attacks, models, datasets, **kwargs):
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    device = P._device()
    progress_bar = ProgressBar('Adversarial')
    for attack, model_name, ds_name in product(attacks, models, datasets):
        attack_name = attack['name']
        if 'rename' in attack:
            name = attack['rename']
        else:
            name = attack_name
        if 'args' in attack:
            args = attack['args']
        else:
            args = {}
        ds_new = '.'.join([ds_name, model_name, name])
        path = P._path_dataset(exp, ds_new)
        progress_bar.set_description(f'{attack_name} {model_name} {ds_name}')
        if os.path.exists(path):
            adv_data = torch.load(path)
            examples = adv_data['images']
            labels = adv_data['labels']
        else:
            attack_func = getattr(adversarials, attack_name)
            model = P._model_load(exp, model_name)
            num_classes = len(P._ds_prop(exp).classes)
            data = P._ds_get(exp, ds_name, False)
            dataloader = torch.utils.data.DataLoader(data, batch_size=100, shuffle=False)
            examples = []
            labels = []
            progress_bar.reset(len(dataloader))
            for images, targets in dataloader:
                adv_example = attack_func(model.to(device), num_classes, images.to(device), targets.to(device), **args)
                examples.append(adv_example)
                labels.append(targets)
                progress_bar.update()
            examples = torch.cat(examples, dim=0)
            labels = torch.cat(labels, dim=0)
            adv_data = {'images': examples, 'labels': labels}
            torch.save(adv_data, path)
        P._ds(exp)[ds_new] = torch.utils.data.TensorDataset(examples, labels)

def visual_dataset(exp, datasets, grid_nrow, plot_nrow, **kwargs):
    grids = []
    titles = []
    for ds in datasets:
        ds_list = ['.'.join([str(t) for t in tup]) for tup in product(*ds.name)]
        for ds_name in ds_list:
            data = P._ds(exp)[ds_name]
            start = ds.start
            length = ds.len
            imgs = []
            if start == 'end':
                start = len(data) - length
            for i in range(start, length):
                img, _ = data[i]
                imgs.append(img)
            grids.append(make_grid(imgs, nrow=grid_nrow))
            titles.append(f'{ds_name}/{ds.start}/{ds.len}')
    utils.visual.imshow(grids, nrow=plot_nrow, titles=titles)

def synthesize_dataset(exp, base_datasets, new_datasets, seed=12):
    ds_all = torch.utils.data.ConcatDataset([P._ds(exp)[ds] for ds in base_datasets])
    for new_ds in new_datasets:
        subsets = _percent_split(ds_all, new_ds['percent'], random=True, generator=torch.Generator().manual_seed(seed))
        for i, name in enumerate(new_ds['name']):
            P._ds(exp)[name] = subsets[i]

def concat_dataset(exp, name, order, **kwargs):
    ds_news = ['.'.join([str(t) for t in tup]) for tup in product(*name)]
    dataset_list = []
    for ds in order:
        datasets = ['.'.join([str(t) for t in tup]) for tup in product(*ds['datasets'])]
        dataset_list.append(datasets)
    ds_list = list(product(*dataset_list))
    if len(ds_news) != len(ds_list):
        raise ValueError('Dataset names number not equal concat datasets number')
    for ds_new, tup in zip(ds_news, ds_list):
        ds_list = [P._ds(exp)[ds] for ds in tup]
        P._ds(exp)[ds_new] = torch.utils.data.ConcatDataset(ds_list)

def split_dataset(exp, datasets, splits, random=False, seed=110, **kwargs):
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for ds_name in datasets:
        for split in splits:
            if 'percent' in split:
                subsets = _percent_split(P._ds(exp)[ds_name], split['percent'], random=random, generator=torch.Generator().manual_seed(seed))
            if 'length' in split:
                subsets = _length_split(P._ds(exp)[ds_name], split['length'], random=random, generator=torch.Generator().manual_seed(seed))
            for i, name in enumerate(split['name']):
                ds_new = '.'.join([ds_name, name])
                P._ds(exp)[ds_new] = subsets[i]

def prioritize_dataset(exp, metrics, models, datasets):
    calc_metric(exp, [{'name': m} for m in metrics], models, datasets)
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for metric_name, model_name, ds_name in product(metrics, models, datasets):
        ds_new = '.'.join([ds_name, model_name, metric_name])
        _ds_prioritize(exp, ds_new, metric_name, model_name, ds_name)
        
def count_dataset_labels(exp, datasets):
    df = _load_labels_count(exp)
    num_classes = len(P._ds_prop(exp).classes)
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    progress_bar = ProgressBar('Count Labels')
    for ds_name in datasets:
        if ds_name in df.columns:
            continue
        counts = torch.zeros(num_classes)
        data_loader = torch.utils.data.DataLoader(
            P._ds_get(exp, ds_name, False), batch_size=100, shuffle=False)
        progress_bar.reset(len(data_loader))
        for _, labels in data_loader:
            counts = counts + torch.bincount(labels, minlength=num_classes)
            progress_bar.update()
        df[ds_name] = counts.cpu().numpy()
    df.to_csv(P._path_labels_count(exp))

def _load_labels_count(exp) -> pd.DataFrame:
    path = P._path_labels_count(exp)
    if os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    return df

def _percent_split(dataset, percent, random=False, generator=torch.Generator()):
    if sum(percent) != 100:
        raise ValueError('Sum of input percent not equal 100')
    lengths = [int(p*len(dataset)//100) for p in percent]
    return _length_split(dataset, lengths, random, generator)

def _length_split(dataset, lengths, random, generator):
    if sum(lengths) != len(dataset):  # type: ignore[arg-type]
        raise ValueError("Sum of input lengths does not equal the length of the input dataset!")
    if random:
        return torch.utils.data.random_split(dataset, lengths, generator=generator)
    indices = torch.arange(len(dataset)).tolist()
    return [torch.utils.data.Subset(dataset, indices[offset - length : offset]) for offset, length in zip(_accumulate(lengths), lengths)]

def _ds_prioritize(exp, ds_new, metric_name, model_name, ds_name):
    m = P._exp_metrics(exp, model_name, ds_name)[metric_name]
    metric = m['metric']
    descending = bool(m['prop']['descending'])
    indices = metric.argsort(descending=descending).tolist()
    P._ds(exp)[ds_new] = torch.utils.data.Subset(P._ds(exp)[ds_name], indices)

def _get_transform(transforms):
    tranform_list = []
    for tran in transforms:
        attr = utils.get_module(tran['name'])
        if 'instantiate' in tran:
            instantiate = tran['instantiate']
        else:
            instantiate = False
        if 'args' in tran:
            args = tran['args']
        else:
            args = {}
        if instantiate:
            transform = attr(**args)
        else:
            transform = attr
        tranform_list.append(transform)
    return tranform_list
