import os
import torch
import datasets
import pandas as pd
import torch.nn.functional as F
from easydict import EasyDict
from .model import _model_predict, _mc_dropout_predict

def _ds_init(exp, dataset, classes, train_transforms, test_transforms, target_transforms):
    ds = datasets.ExpDataset(dataset['train'], transforms=train_transforms, target_transforms= target_transforms)
    data, _ = ds[0]
    shape = data.shape
    exp.info['ds'] = EasyDict({
        'dataset': dataset,
        'prop': {'shape': shape, 'classes': classes, 'train_transforms': train_transforms, 'test_transforms': test_transforms,'target_transforms': target_transforms}
    })

def _ds(exp):
    return exp.info['ds'].dataset

def _ds_prop(exp):
    return exp.info['ds'].prop

def _ds_get(exp, name, train=False):
    ds = _ds(exp)
    if name not in ds:
        return None
    if train:
        transforms = _ds_prop(exp)['train_transforms']
    else:
        transforms = _ds_prop(exp)['test_transforms']
    target_transforms = _ds_prop(exp)['target_transforms']
    return datasets.ExpDataset(ds[name], transforms=transforms, target_transforms= target_transforms)


def _get_probs(exp, model, dataset):
    key = (model, dataset)
    if key in _exp_probs(exp):
        return _exp_probs(exp)[key]
    path = _probs_path(exp, model, dataset)
    if not os.path.exists(path):
        _model_predict(exp, model, dataset)
    df = pd.read_csv(path, index_col=0)
    probs = torch.from_numpy(df.values)
    _exp_probs(exp)[key] = probs
    return probs

def _exp_probs(exp):
    if 'probs' not in exp.info:
        exp.info['probs'] = {}
    return exp.info['probs']

def _get_prediction(exp, model, dataset):
    key = (model, dataset)
    if key in _exp_prediction(exp):
        return _exp_prediction(exp)[key]
    path = _probs_path(exp, model, dataset)
    if not os.path.exists(path):
        _model_predict(exp, model, dataset)
    path = _prediction_path(exp, dataset)
    df = pd.read_csv(path, index_col=0)
    for m in df.columns:
        prediction = torch.from_numpy(df[m].values)
        _exp_prediction(exp)[(m, dataset)] = prediction
    return _exp_prediction(exp)[key]

def _exp_prediction(exp):
    if 'prediction' not in exp.info:
        exp.info['prediction'] = {}
    return exp.info['prediction']

def _get_mc_logits(exp, model, dataset, n_mc):
    key = (model, dataset)
    path = _mc_logits_path(exp, model, dataset)
    if key in _mc_logits(exp):
        logits = _mc_logits(exp)[key]
    else:
        if os.path.exists(path):
            logits = torch.load(path)
        else:
            logits = _mc_dropout_predict(exp, model, dataset, n_mc)
            torch.save(logits, path)
        _mc_logits(exp)[key] = logits
    
    if logits.size(0) < n_mc:
        new_logits = _mc_dropout_predict(exp, model, dataset, n_mc - logits.size(0))
        logits = torch.cat([logits, new_logits], dim=0)
        torch.save(logits, path)
        _mc_logits(exp)[key] = logits        
    return logits[:n_mc]

def _get_mc_probs(exp, model, dataset, n_mc):
    logits = _get_mc_logits(exp, model, dataset, n_mc)
    probs = F.softmax(logits, dim=-1)
    return probs

def _mc_logits(exp):
    if 'mc_logits' not in exp.info:
        exp.info['mc_logits'] = {}
    return exp.info['mc_logits']

def _exp_metrics(exp, model, dataset):
    key = (model, dataset)
    if 'metrics' not in exp.info:
        exp.info['metrics'] = {}
    if key not in exp.info['metrics']:
        exp.info['metrics'][key] = {}
    return exp.info['metrics'][key]

def _model_load(exp, model_name):
    if not os.path.exists(_model_path(exp, model_name)):
        return None
    model = torch.load(_model_path(exp, model_name), map_location=_device())
    return model

def _model_path(exp, model_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}.pth')

def _mc_logits_path(exp, model_name, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-{ds_name}-mc_logits.pth')

def _pretrained_path(exp, architecture, dataset_name):
    return os.path.join(exp.env.pretrained_root, dataset_name, architecture + '.pt')

def _train_log_path(exp, model_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-log.csv')

def _logits_path(exp, model_name, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-{ds_name}-logits.csv')

def _probs_path(exp, model_name, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-{ds_name}-probs.csv')

def _prediction_path(exp, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{ds_name}-prediction.csv')

def _accuracy_path(exp):
    return os.path.join(exp.exp_dir, f'{exp.id}-accuracy.csv')

def _btc_path(exp, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{ds_name}-btc.csv')

def _bec_path(exp, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{ds_name}-bec.csv')

def _nfr_path(exp, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{ds_name}-nfr.csv')

def _nfr_rel_path(exp, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{ds_name}-nfr_rel.csv')

def _nfr_rel_1_path(exp, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{ds_name}-nfr_rel_1.csv')

def _path_kendall(exp, model_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-kendall.csv')

def _path_apfd(exp, model_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-apfd.csv')

def _path_rauc(exp, model_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-rauc.csv')

def _path_metrics(exp, model_name, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-{ds_name}-metrics.csv')

def _path_metric_props(exp, model_name, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{model_name}-{ds_name}-metric_props.csv')

def _path_labels_count(exp):
    return os.path.join(exp.exp_dir, f'{exp.id}-labels_count.csv')

def _path_dataset(exp, ds_name):
    return os.path.join(exp.exp_dir, f'{exp.id}-{ds_name}.pth')

def _update_accuracy(exp, model_name, ds_name, acc):
    path = _accuracy_path(exp)
    if 'accuracy_df' in exp.info:
        df = exp.info['accuracy_df']
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[model_name, ds_name] = acc
    df.to_csv(path)
    exp.info['accuracy_df'] = df

def _update_btc(exp, old_model, new_model, dataset, btc):
    path = _btc_path(exp, dataset)
    if 'btc_df' not in exp.info:
        exp.info['btc_df'] = {}
    if dataset in exp.info['btc_df']:
        df = exp.info['btc_df'][dataset]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[old_model, new_model] = btc
    df.to_csv(path)
    exp.info['btc_df'][dataset] = df

def _update_bec(exp, old_model, new_model, dataset, bec):
    path = _bec_path(exp, dataset)
    if 'bec_df' not in exp.info:
        exp.info['bec_df'] = {}
    if dataset in exp.info['bec_df']:
        df = exp.info['bec_df'][dataset]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[old_model, new_model] = bec
    df.to_csv(path)
    exp.info['bec_df'][dataset] = df

def _update_nfr(exp, old_model, new_model, dataset, nfr):
    path = _nfr_path(exp, dataset)
    if 'nfr_df' not in exp.info:
        exp.info['nfr_df'] = {}
    if dataset in exp.info['nfr_df']:
        df = exp.info['nfr_df'][dataset]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[old_model, new_model] = nfr
    df.to_csv(path)
    exp.info['nfr_df'][dataset] = df

def _update_nfr_rel(exp, old_model, new_model, dataset, nfr_rel):
    path = _nfr_rel_path(exp, dataset)
    if 'nfr_rel_df' not in exp.info:
        exp.info['nfr_rel_df'] = {}
    if dataset in exp.info['nfr_rel_df']:
        df = exp.info['nfr_rel_df'][dataset]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[old_model, new_model] = nfr_rel
    df.to_csv(path)
    exp.info['nfr_rel_df'][dataset] = df

def _update_nfr_rel_1(exp, old_model, new_model, dataset, nfr_rel_1):
    path = _nfr_rel_1_path(exp, dataset)
    if 'nfr_rel_1_df' not in exp.info:
        exp.info['nfr_rel_1_df'] = {}
    if dataset in exp.info['nfr_rel_1_df']:
        df = exp.info['nfr_rel_1_df'][dataset]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[old_model, new_model] = nfr_rel_1
    df.to_csv(path)
    exp.info['nfr_rel_1_df'][dataset] = df

def _update_kendall(exp, metric_name, model_name, ds_name, kendall):
    path = _path_kendall(exp, model_name)
    if 'kendall' not in exp.info:
        exp.info['kendall'] = {}
    if model_name in exp.info['kendall']:
        df = exp.info['kendall'][model_name]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[ds_name, metric_name] = kendall
    df.to_csv(path)
    exp.info['kendall'][model_name] = df

def _update_apfd(exp, metric_name, model_name, ds_name, apfd):
    path = _path_apfd(exp, model_name)
    if 'apfd' not in exp.info:
        exp.info['apfd'] = {}
    if model_name in exp.info['apfd']:
        df = exp.info['apfd'][model_name]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[ds_name, metric_name] = apfd
    df.to_csv(path)
    exp.info['apfd'][model_name] = df

def _update_rauc(exp, metric_name, model_name, ds_name, topk, rauc_score):
    path = _path_rauc(exp, model_name)
    if 'rauc' not in exp.info:
        exp.info['rauc'] = {}
    if model_name in exp.info['rauc']:
        df = exp.info['rauc'][model_name]
    elif os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    df.loc[f'{ds_name}/{topk}', metric_name] = rauc_score
    df.to_csv(path)
    exp.info['rauc'][model_name] = df

def _device():
    return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
