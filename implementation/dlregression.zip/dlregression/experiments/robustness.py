from itertools import product
import os
import pandas as pd
import torch
from art.estimators.classification import PyTorchClassifier
from art.metrics.metrics import empirical_robustness, clever_t, clever_u, clever, loss_sensitivity, wasserstein_distance
from . import private as P

__all__ = ['calc_clever_score']

def calc_clever_score(exp, models, datasets):
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for model_name, ds_name in product(models, datasets):
        _clever_score(exp, model_name, ds_name)

def _clever_score(exp, model_name, ds_name):
    model = P._model_load(exp, model_name)
    ds = P._ds_get(exp, ds_name, False)
    if ds is None:
        print(f'Warning dataset {ds_name} not exits skip...')
        return
    input_shape = P._ds_prop(exp).shape
    num_classes = len(P._ds_prop(exp).classes)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9, weight_decay=1.e-6, nesterov=True)
    criterion = torch.nn.CrossEntropyLoss()
    classifier = PyTorchClassifier(
        model=model,
        loss=criterion,
        input_shape=input_shape,
        nb_classes=num_classes,
        optimizer=optimizer
    )
    clever_df = _load_clever(exp, ds_name)
    if (model_name in clever_df.columns):
        return
    scores = []
    for i in range(len(ds)):
        score = clever_u(classifier, ds[i][0].numpy(), 10, 10, 5, norm=2, pool_factor=3)
        print(i, ':', score)
        scores.append(score)
    clever_df[model_name] = scores
    clever_df.to_csv(P._clever_path(exp, ds_name))

def _load_clever(exp, ds_name) -> pd.DataFrame:
    path = P._clever_path(exp, ds_name)
    if os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    return df