import torch
from itertools import product
from . import dataset as DS
from . import metric as MET
from . import model as MOD
from . import compatibility as COMP
from . import private as P
from . import robustness as ROB
__all__ = ['retrain_model', 'active_retrain']

def retrain_model(exp, model_origin, model_name, train_datasets, val_datasets, criterions, **kwargs):
    model_news = ['.'.join([str(t) for t in tup]) for tup in product(*model_name)]
    train_datasets = ['.'.join([str(t) for t in tup]) for tup in product(*train_datasets)]
    val_datasets = ['.'.join([str(t) for t in tup]) for tup in product(*val_datasets)]
    if (len(model_news) != len(train_datasets)) or (len(model_news) != len(train_datasets)):
        raise ValueError('number of model_name train_datasets val_datasets are not equal')
    for m, train_data, val_data in zip(model_news, train_datasets, val_datasets):
        for c in criterions:
            if 'args' not in c:
                c['args'] = [{}]
            if 'name' not in c:
                c['name'] = [f'{c["criterion"]}.{i}' for i in range(len(c['args']))]
            criterion_list = [{'name': c['criterion'], 'args': args} for args in c['args']]
            for name, criterion in zip(c['name'], criterion_list):
                model_name = f'{m}.{name}'
                _retrain_one_model(exp, model_origin, model_name, train_data, val_data, criterion=criterion, **kwargs)

def active_retrain(exp, model_origin, model_name, metrics, window, train_origin, train_data, val_data, repeat=1, eval_compat=False, eval_clever=False, **kwargs):
    ds_length = len(P._ds(exp)[train_data])
    steps = (ds_length + window -1) // window
    for metric in metrics:
        ds_train = train_origin
        ds_left = train_data
        left_len = ds_length
        mod = model_origin
        for i in range(steps):
            MET._metric_calc(exp, metric, mod, ds_left)
            metric_name = metric['name']
            if 'rename' in metric:
                metric_name = metric['rename']
            ds_prio = '.'.join([model_name, metric_name, str(i), 'prio'])
            DS._ds_prioritize(exp, ds_prio, metric_name, mod, ds_left)            
            train_len = min(window, left_len)
            left_len -= train_len
            new_train, new_left = DS._length_split(P._ds(exp)[ds_prio], [train_len, left_len], random=False, generator=None)
            new_train = torch.utils.data.ConcatDataset([P._ds(exp)[ds_train], new_train])
            ds_train = '.'.join([model_name, metric_name, str(i), 'train'])
            ds_left = '.'.join([model_name, metric_name, str(i), 'left'])
            P._ds(exp)[ds_train] = new_train
            P._ds(exp)[ds_left] = new_left
            model_new = '.'.join([model_name, metric_name, str(i)])
            models_name = [model_new]
            for i in range(1, repeat):
                models_name.append('.'.join([model_new, str(i)]))
            print(models_name)
            for m_name in models_name:
                    _retrain_one_model(exp, mod, m_name, ds_train, val_data, **kwargs)
            mod = model_new
        if eval_compat:
            compat_datasets = ['.'.join([str(t) for t in tup]) for tup in product(*eval_compat['datasets'])]
            for ds in compat_datasets:
                for i in range(steps):
                    nm = '.'.join([model_name, metric_name, str(i)])
                    COMP._evaluate_compat(exp, model_origin, nm, ds)
                    for j in range(i):
                        om = '.'.join([model_name, metric_name, str(j)])
                        COMP._evaluate_compat(exp, om, nm, ds)
        if eval_clever:
            eval_datasets = ['.'.join([str(t) for t in tup]) for tup in product(*eval_clever['datasets'])]
            for ds in eval_datasets:
                ROB._clever_score(exp, model_origin, ds)
                for i in range(steps):
                    nm = '.'.join([model_name, metric_name, str(i)])
                    ROB._clever_score(exp, nm, ds)

def _retrain_one_model(exp, model_origin, model_name, train_data, val_data, **kwargs):
    model = P._model_load(exp, model_origin)
    model_old = P._model_load(exp, model_origin)
    MOD._train_one_model(exp, model_name, model, train_data, val_data, model_old=model_old, **kwargs)


        