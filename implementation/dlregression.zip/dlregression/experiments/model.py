import os
import torch
import models
import support
import numpy as np
import pandas as pd
import torch.nn.functional as F
from utils import ProgressBar
from itertools import product
from . import private as P

__all__ = ['load_pretrained_model', 'train_model', 'retrain_model', 'predict_model']

def load_pretrained_model(exp, model_name, architecture, dataset_name):
    path = P._model_path(exp, model_name)
    if os.path.exists(path):
        return
    md = getattr(models, architecture)
    input_shape = P._ds_prop(exp).shape
    num_classes = len(P._ds_prop(exp).classes)
    model = md(input_shape = input_shape, num_classes = num_classes)
    state_dict = torch.load(P._pretrained_path(exp, architecture, dataset_name))
    model.load_state_dict(state_dict)
    torch.save(model, path)

def train_model(exp, model_name, architecture, train_data, val_data, batch_size=1, **kwargs):
    md = getattr(models, architecture)
    input_shape = P._ds_prop(exp).shape
    num_classes = len(P._ds_prop(exp).classes)
    model = md(input_shape = input_shape, num_classes = num_classes)
    _train_one_model(exp, model_name, model, train_data, val_data, batch_size, **kwargs)

def retrain_model(exp, model_origin, model_name, train_datasets, val_datasets, criterions, batch_size=1, **kwargs):
    model_news = ['.'.join([str(t) for t in tup]) for tup in product(*model_name)]
    train_datasets = ['.'.join([str(t) for t in tup]) for tup in product(*train_datasets)]
    val_datasets = ['.'.join([str(t) for t in tup]) for tup in product(*val_datasets)]
    if (len(model_news) != len(train_datasets)) or (len(model_news) != len(train_datasets)):
        raise ValueError('number of model_name train_datasets val_datasets are not equal')
    for m, train_data, val_data in zip(model_news, train_datasets, val_datasets):
        for c in criterions:
            if 'args' not in c:
                c['args'] = [{}]
            if 'name' not in c:
                c['name'] = [f'{c["criterion"]}.{i}' for i in range(len(c['args']))]
            criterion_list = [{'name': c['criterion'], 'args': args} for args in c['args']]
            for name, criterion in zip(c['name'], criterion_list):
                model_name = f'{m}.{name}'
                model = P._model_load(exp, model_origin)
                model_old = P._model_load(exp, model_origin)
                _train_one_model(exp, model_name, model, train_data, val_data, batch_size, model_old=model_old, criterion=criterion, **kwargs)

def predict_model(exp, models, datasets, **kwargs):
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for model_name, ds_name in product(models, datasets):
        _model_predict(exp, model_name, ds_name)

def _model_predict(exp, model_name, ds_name):
    ds = P._ds_get(exp, ds_name, False)
    progress_bar = ProgressBar('Predict')
    if ds is None:
        print(f'Warning dataset {ds_name} not exits skip...')
        return
    logits_path = P._logits_path(exp, model_name, ds_name)
    probs_path = P._probs_path(exp, model_name, ds_name)
    prediction_df = _load_prediction(exp, ds_name)
    if os.path.exists(logits_path) and os.path.exists(probs_path) and (model_name in prediction_df.columns):
        return
    model = P._model_load(exp, model_name)
    if model is None and model_name != 'ground_truth':
        print(f'Warning model {model_name} not exits skip...')
        return
    data_loader = torch.utils.data.DataLoader(
        ds, batch_size=100, shuffle=False)
    progress_bar.set_description(f'{model_name}-{ds_name}')
    if model != None:
        model.eval()
    logits, ground_truth = _model_predict_one(model, data_loader, progress_bar)
    if model != None:
        probs = F.softmax(logits, dim=1)
        prediction = probs.argmax(dim=1)
        accuracy = 100. * prediction.eq(ground_truth).sum().item() / prediction.size(0)
        logits_df = pd.DataFrame(logits.cpu().numpy())
        logits_df.to_csv(logits_path)
        probs_df = pd.DataFrame(probs.cpu().numpy())
        probs_df.to_csv(probs_path)
        prediction_df[model_name] = prediction.cpu().numpy()
        P._update_accuracy(exp, model_name, ds_name, accuracy)
    if 'ground_truth' not in prediction_df.columns:
        prediction_df['ground_truth'] = ground_truth.cpu().numpy()    
    prediction_df.to_csv(P._prediction_path(exp, ds_name))

def _mc_dropout_predict(exp, model_name, dataset_name, n_mc):
    progress_bar = ProgressBar('Predict MC Dropout')
    model = P._model_load(exp, model_name)
    if model is None:
        print(f'Warning dataset {model_name} not exits skip...')
        return
    ds = P._ds_get(exp, dataset_name, False)
    data_loader = torch.utils.data.DataLoader(
        ds, batch_size=100, shuffle=False)
    mc_logits = []
    for i in range(n_mc):
        model.train()
        logits, _ = _model_predict_one(model, data_loader, progress_bar)
        mc_logits.append(logits)
    return torch.stack(mc_logits)

def _train_one_model(exp, model_name, model, train_data, val_data, batch_size=1, model_old=None, **kwargs):
    if os.path.exists(P._train_log_path(exp, model_name)):
        return
    ds_train = P._ds_get(exp, train_data, True)
    ds_val = P._ds_get(exp, val_data, False)
    path = P._model_path(exp, model_name)
    train_loader = torch.utils.data.DataLoader(
        ds_train, batch_size=batch_size, shuffle=True)
    val_loader = torch.utils.data.DataLoader(
        ds_val, batch_size=batch_size, shuffle=False)
    logs = _model_train(model, train_loader=train_loader, val_loader=val_loader, path=path, model_old=model_old, **kwargs)
    df = pd.DataFrame(logs)
    df.to_csv(P._train_log_path(exp, model_name), index=False)

def _model_train(model, train_loader, val_loader, epochs, optimizer, criterion, model_old, lr_scheduler=None, path=None, **kwargs):
    device = P._device()
    model = model.to(device)
    if model_old is not None:
        model_old = model_old.to(device)
        model_old.eval()
    optimizer = _get_optimizer(model, optimizer)
    criterion = _get_criterion(criterion)
    lr_scheduler = _get_lr_scheduler(optimizer, lr_scheduler)
    train_bar = ProgressBar('Train')
    val_bar = ProgressBar('Validate')

    logs = []
    best_acc = 0
    val_loss, val_acc = _validate(model, criterion, val_loader, device, val_bar, model_old=model_old)
    logs.append({'epoch': 0, 'train_loss': np.nan, 'train_acc': np.nan, 'val_loss': val_loss, 'val_acc': val_acc, 'lr': optimizer.state_dict()['param_groups'][0]['lr']})
    # if path is not None:
    #     torch.save(model, path)
    # best_acc = val_acc
    for epoch in range(1, epochs+1):
        train_bar.set_description(f'Epoch {epoch}')
        train_loss, train_acc = _train(model, optimizer, criterion, train_loader, device, train_bar, model_old=model_old, **kwargs)
        val_loss, val_acc = _validate(model, criterion, val_loader, device, val_bar, model_old=model_old)
        lr_scheduler.step()

        if val_acc > best_acc:
            if path is not None:
                torch.save(model, path)
            best_acc = val_acc
        logs.append({'epoch': epoch, 'train_loss': train_loss, 'train_acc': train_acc, 'val_loss': val_loss, 'val_acc': val_acc, 'lr': optimizer.state_dict()['param_groups'][0]['lr']})
        
    return logs

def _model_predict_one(model, data_loader, progress_bar):
    device = P._device()
    if model != None:
        model = model.to(device)
    logits = []
    ground_truth = []
    progress_bar.reset(len(data_loader))
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(data_loader):
            inputs, targets = inputs.to(device), targets.to(device)
            if model != None:
                outputs = model(inputs)
                logits.append(outputs)
            ground_truth.append(targets)            
            progress_bar.update()
    if model != None:
        logits = torch.cat(logits, dim=0)
    ground_truth = torch.cat(ground_truth)
    return logits, ground_truth

def _train(model, optimizer, criterion, data_loader, device, progress_bar, model_old, mixup=None, dissonance=None):
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    progress_bar.reset(len(data_loader))
    for batch_idx, (inputs, targets) in enumerate(data_loader):
        inputs, targets = inputs.to(device), targets.to(device)
        if mixup is not None:
            inputs, targets_a, targets_b, lam = support.mixup.mixup_data(inputs, targets, mixup['alpha'], device)
            criterion_fn = support.mixup.mixup_criterion(targets_a, targets_b, lam)
        optimizer.zero_grad()
        outputs = model(inputs)
        if mixup is not None:
            loss = criterion_fn(criterion, outputs)
        else:
            loss = criterion(outputs, targets)
            if dissonance is not None:
                with torch.no_grad():
                    outputs_old = model_old(inputs)
                loss += _dissonace(dissonance, outputs, outputs_old, targets)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        predicted = outputs.argmax(dim=1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
        progress_bar.update()
        progress_bar.set_postfix({'Loss': train_loss/(batch_idx+1), 'Acc': 100.*correct/total})
    return train_loss/(batch_idx+1), 100.*correct/total

def _validate(model, criterion, data_loader, device, progress_bar, model_old):
    model.eval()
    val_loss = 0
    correct = 0
    total = 0
    progress_bar.reset(len(data_loader))
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(data_loader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            if hasattr(criterion, 'origin'):
                outputs_old = model_old(inputs)
                loss = criterion(outputs, targets, outputs_old)
            else:
                loss = criterion(outputs, targets)

            val_loss += loss.item()
            predicted = outputs.argmax(dim=1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()
            progress_bar.update()
            progress_bar.set_postfix({'Loss': val_loss/(batch_idx+1), 'Acc': 100.*correct/total})
    return val_loss/(batch_idx+1), 100.*correct/total

def _get_optimizer(model, config):
    optimizer = getattr(torch.optim, config['name'])
    if 'args' in config:
        args = config['args']
    else:
        args = {}
    return optimizer(model.parameters(), **args)


def _get_criterion(config):
    criterion = getattr(support.loss, config['name'])
    if 'args' in config:
        args = config['args']
    else:
        args = {}
    return criterion(**args)

class dummy_lr_scheduler:
    def step(self):
        pass

def _get_lr_scheduler(optimizer, config):
    if config is None:
        return dummy_lr_scheduler()
    scheduler = getattr(torch.optim.lr_scheduler, config['name'])
    if 'args' in config:
        args = config['args']
    else:
        args = {}
    return scheduler(optimizer, **args)

def _load_prediction(exp, ds_name) -> pd.DataFrame:
    path = P._prediction_path(exp, ds_name)
    if os.path.exists(path):
        df = pd.read_csv(path, index_col=0)
    else:
        df = pd.DataFrame()
    return df

def _dissonace(dissonance, outputs, outputs_old, targets):
    alpha = dissonance['alpha']
    beta = dissonance['beta']
    distance = _get_criterion(dissonance['distance'])
    correct_h1 = outputs_old.argmax(dim=1).eq(targets)
    h1_x = outputs_old[correct_h1]
    h2_x = outputs[correct_h1]
    return alpha * distance(outputs_old, outputs) + beta * distance(h1_x, h2_x)
