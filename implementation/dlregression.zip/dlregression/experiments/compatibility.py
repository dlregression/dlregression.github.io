from itertools import product
from . import private as P

__all__ = ['evaluate_compatibility']

def evaluate_compatibility(exp, old_model, new_models, datasets):
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for ds in datasets:
        for tup in product(*new_models):
            m = '.'.join([str(t) for t in tup])
            _evaluate_compat(exp, old_model, m, ds)

def _evaluate_compat(exp, old_model, new_model, dataset):
    truth = P._get_prediction(exp, 'ground_truth', dataset)
    pred_h1 = P._get_prediction(exp, old_model, dataset)
    pred_h2 = P._get_prediction(exp, new_model, dataset)
    btc_val = btc(pred_h1, pred_h2, truth)
    bec_val = bec(pred_h1, pred_h2, truth)
    nfr_val = nfr(pred_h1, pred_h2, truth)
    nfr_rel_val = nfr_rel(pred_h1, pred_h2, truth)
    nfr_rel_1_val = nfr_rel_1(pred_h1, pred_h2, truth)
    P._update_btc(exp, old_model, new_model, dataset, btc_val)
    P._update_bec(exp, old_model, new_model, dataset, bec_val)
    P._update_nfr(exp, old_model, new_model, dataset, nfr_val)
    P._update_nfr_rel(exp, old_model, new_model, dataset, nfr_rel_val)
    P._update_nfr_rel_1(exp, old_model, new_model, dataset, nfr_rel_1_val)

def btc(pred_h1, pred_h2, truth):
    correct_h1 = pred_h1.eq(truth)
    correct_h2 = pred_h2.eq(truth)
    val = correct_h2.masked_select(correct_h1).count_nonzero() / correct_h1.count_nonzero()
    return 100. * val.item()

def bec(pred_h1, pred_h2, truth):
    wrong_h1 = ~pred_h1.eq(truth)
    wrong_h2 = ~pred_h2.eq(truth)
    val = wrong_h2.masked_select(wrong_h1).count_nonzero() / wrong_h2.count_nonzero()
    return 100. * val.item()

def nfr(pred_h1, pred_h2, truth):
    correct_h1 = pred_h1.eq(truth)
    wrong_h2 = ~pred_h2.eq(truth)
    negative_flip = wrong_h2.masked_select(correct_h1)
    val = negative_flip.count_nonzero() / truth.size(0)
    return 100. * val.item()

def nfr_rel(pred_h1, pred_h2, truth):
    wrong_h1 = ~pred_h1.eq(truth)
    wrong_h2 = ~pred_h2.eq(truth)
    er_old = wrong_h1.count_nonzero() / truth.size(0)
    er_new = wrong_h2.count_nonzero() / truth.size(0)
    val = nfr(pred_h1, pred_h2, truth) / ((1 - er_old) * er_new)
    return val.item()

def nfr_rel_1(pred_h1, pred_h2, truth):
    wrong_h2 = ~pred_h2.eq(truth)
    er_new = wrong_h2.count_nonzero() / truth.size(0)
    val = nfr(pred_h1, pred_h2, truth) / er_new
    return val.item()