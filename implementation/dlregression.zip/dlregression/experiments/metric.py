import os
import sys
import torch
import pandas as pd
import torch.nn.functional as F
import numpy as np
from scipy.stats import kendalltau
from itertools import product
from . import private as P

__all__ = ['calc_metric', 'calc_kendall', 'calc_apfd', 'calc_rauc']
def calc_rauc(exp, metrics, models, datasets, topks):
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for metric_name, model_name, ds_name in product(metrics, models, datasets):
        m = P._exp_metrics(exp, model_name, ds_name)[metric_name]
        metric = m['metric']
        descending = bool(m['prop']['descending'])
        truth = P._get_prediction(exp, 'ground_truth', ds_name)
        pred = P._get_prediction(exp, model_name, ds_name)
        misclass = (pred!=truth)
        rank, indeces = rank_metric(metric, descending)
        for topk in topks:
            rauc_score = rauc(misclass, rank, indeces, topk).item()
            P._update_rauc(exp, metric_name, model_name, ds_name, topk, rauc_score)

def calc_apfd(exp, metrics, models, datasets):
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for metric_name, model_name, ds_name in product(metrics, models, datasets):
        m = P._exp_metrics(exp, model_name, ds_name)[metric_name]
        metric = m['metric']
        descending = bool(m['prop']['descending'])
        truth = P._get_prediction(exp, 'ground_truth', ds_name)
        pred = P._get_prediction(exp, model_name, ds_name)
        misclass = (pred!=truth)
        rank, _ = rank_metric(metric, descending)
        apfdscore = apfd(misclass, rank).item()
        P._update_apfd(exp, metric_name, model_name, ds_name, apfdscore)

def calc_kendall(exp, metrics, models, datasets):
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for metric_name, model_name, ds_name in product(metrics, models, datasets):
        m = P._exp_metrics(exp, model_name, ds_name)[metric_name]
        metric = m['metric']
        truth = P._get_prediction(exp, 'ground_truth', ds_name)
        pred = P._get_prediction(exp, model_name, ds_name)
        correct = pred.eq(truth)
        kendallscore, p = kendalltau(metric.cpu().numpy(), correct.cpu().numpy())
        P._update_kendall(exp, metric_name, model_name, ds_name, kendallscore)

def calc_metric(exp, metrics, models, datasets):
    models = ['.'.join([str(t) for t in tup]) for tup in product(*models)]
    datasets = ['.'.join([str(t) for t in tup]) for tup in product(*datasets)]
    for model_name, ds_name in product(models, datasets):
        _load_exp_metrics(exp, model_name, ds_name)
        for metric in metrics:
            _metric_calc(exp, metric, model_name, ds_name)
    _save_exp_metrics(exp)

def _metric_calc(exp, metric, model_name, ds_name):
    metric_name = metric['name']
    if 'rename' in metric:
        metric_name = metric['rename']
    if metric_name in P._exp_metrics(exp, model_name, ds_name):
        return
    if 'args' in metric:
        args = metric['args']
    else:
        args = {}
    calc = _find_metric(metric['name'])
    value, prop = calc(exp, model_name, ds_name, **args)
    P._exp_metrics(exp, model_name, ds_name)[metric_name] = {'metric': value, 'prop': prop}

def _save_exp_metrics(exp):
    for (model, dataset), metrics in exp.info['metrics'].items():
        metric_df = pd.DataFrame()
        prop_df = pd.DataFrame()
        for metric_name, metric in metrics.items():
            metric_df[metric_name] = metric['metric'].cpu().numpy()
            prop_df = prop_df.append(pd.Series(metric['prop'], name=metric_name))
        metric_df.to_csv(P._path_metrics(exp, model, dataset))
        prop_df.to_csv(P._path_metric_props(exp, model, dataset))

def _load_exp_metrics(exp, model, dataset):
    if not os.path.exists(P._path_metrics(exp, model, dataset)):
        return
    if not os.path.exists(P._path_metric_props(exp, model, dataset)):
        return
    metric_df = pd.read_csv(P._path_metrics(exp, model, dataset), index_col=0)
    prop_df = pd.read_csv(P._path_metric_props(exp, model, dataset), index_col=0)
    for metric_name in metric_df.columns:
        metric = torch.from_numpy(metric_df[metric_name].values)
        prop = prop_df.loc[metric_name].to_dict()
        P._exp_metrics(exp, model, dataset)[metric_name] = {'metric': metric, 'prop': prop}

def deepgini(probs):
    return 1 - torch.sum(probs**2, dim=1)

# Prediction Confidence Score
def margin(probs):
    top, _ = probs.topk(2, dim=1, largest=True, sorted=True)
    top1, top2 = top.split([1,1], dim=1)
    result = top1 - top2
    return result.flatten()

def entropy(probs):
    return -torch.sum(torch.log2(probs + 1.e-10)*probs, dim=-1)

def mc_expected_entropy(mc_probs):
    """
    Take a tensor mc_probs [n_mc x batch_size x n_classes] and return the
    mean entropy of the predictive distribution across the MC samples.
    """
    return torch.mean(entropy(mc_probs), dim=0)  # batch_size

def mc_predictive_entropy(mc_probs):
    """
    Take a tensor mc_probs [n_mc x batch_size x n_classes] and return the
    entropy of the mean predictive distribution across the MC samples.
    """
    return entropy(torch.mean(mc_probs, dim=0))

def computeKL(result, nb_classes, label):
    nb_samples = result.shape[1]
    hist = np.zeros((nb_samples, nb_classes))
    for i in range(nb_samples):
        l_i = label[:, i]
        for j in range(nb_classes):
            #print(np.sum(l_i == j))
            hist[i][j] = np.sum(l_i == j)

    var_hist = np.var(hist/ label.shape[0], axis=1)

    hist_pdf = hist / label.shape[0]
    uniform_pdf = np.repeat(1 / nb_classes, nb_classes)
    kl = np.zeros(nb_samples)
    import scipy.stats
    for j in range(len(kl)):
        kl[j] = scipy.stats.entropy(np.squeeze(hist_pdf[j]), uniform_pdf)
    return kl, var_hist

def prob_mean(result_test):
    mean_all_class = np.mean(result_test, axis=0)
    p_index = np.argmax(mean_all_class, axis=1)
    p = mean_all_class[np.arange(len(mean_all_class)), p_index]
    var = np.var(mean_all_class, axis=1)
    return p,var

def compute2DHistGroup(score, p, nb_group):
    vmin, vmax = np.min(score), np.max(score)
    pmin, pmax = np.min(p), np.max(p)
    vbins = np.linspace(vmin, vmax, nb_group + 1)
    pbins = np.linspace(pmin, pmax, nb_group + 1)
    vwidth = vbins[1] - vbins[0]
    if vwidth == 0.:
        vwidth = vwidth+0.0000001
    vidx_bins = np.minimum(np.floor((score - vmin) / vwidth), len(vbins) - 1 - 1).astype(int)

    pw = pbins[1] - pbins[0]
    if pw == 0.:
        pw = pw + 0.0000001
    pidx_bins = np.minimum(np.floor((p - pmin) / pw), len(pbins) - 1 - 1).astype(int)

    dic = {}
    t = 0
    for i in range(nb_group):
        dic[i] = {}
        for j in range(nb_group):
            a = np.nonzero(np.logical_and(vidx_bins == i, pidx_bins == j))[0]
            dic[i][j] = np.nonzero(np.logical_and(vidx_bins == i, pidx_bins == j))[0]
            t += len(dic[i][j])

    return dic, score, p, vbins, pbins

def apfd(misclass, rank):
    n = rank.size(0)
    k = misclass.count_nonzero()
    r = rank.masked_select(misclass)
    result = 1 - torch.sum(r)/(k*n) + 1./(2*n)
    return result

def rauc(misclass, rank, indices, topk=0):
    if topk>0:
        n = topk
    else:
        n = rank.size(0)
    misclass = misclass[indices[:n]]
    rank = rank[indices[:n]]
    r = rank.masked_select(misclass)
    k = r.size(0)
    result = k/n - torch.sum(r)/(n*n) + 1./(2*n)
    return result * 2

def rank_metric(metric, descending):
    indices = metric.argsort(descending=descending)
    rank = torch.zeros(indices.size(0), dtype=torch.int)
    rank[indices] = torch.arange(1, indices.size(0) + 1, dtype=torch.int)
    return rank, indices

def deepgini_calc(exp, model, dataset):
    probs = P._get_probs(exp, model, dataset)
    prop = {'descending': True}
    return deepgini(probs), prop

def margin_calc(exp, model, dataset):
    probs = P._get_probs(exp, model, dataset)
    prop = {'descending': False}
    return margin(probs), prop

def pcs_calc(exp, model, dataset):
    return margin_calc(exp, model, dataset)

def entropy_calc(exp, model, dataset):
    probs = P._get_probs(exp, model, dataset)
    prop = {'descending': True}
    return entropy(probs), prop
    
def mc_pe_calc(exp, model, dataset, n_mc):
    mc_logits = P._get_mc_logits(exp, model, dataset, n_mc)
    if mc_logits.size(0)!=n_mc:
        raise ValueError(f'mc_logits:{mc_logits.size(0)} is not n_mc:{n_mc}')
    prop = {'descending': True}
    mc_preds = F.softmax(mc_logits, dim=2)
    return mc_predictive_entropy(mc_preds), prop

def mc_mi_calc(exp, model, dataset, n_mc):
    mc_logits = P._get_mc_logits(exp, model, dataset, n_mc)
    if mc_logits.size(0)!=n_mc:
        raise ValueError(f'mc_logits:{mc_logits.size(0)} is not n_mc:{n_mc}')
    prop = {'descending': True}
    mc_preds = F.softmax(mc_logits, dim=2)
    result = mc_predictive_entropy(mc_preds) - mc_expected_entropy(mc_preds)
    return mc_predictive_entropy(mc_preds), prop

def random_calc(exp, model, dataset):
    probs = P._get_probs(exp, model, dataset)
    prop = {'descending': True}
    return torch.rand(probs.size(0)), prop

def maxp_calc(exp, model, dataset):
    probs = P._get_probs(exp, model, dataset)
    prop = {'descending': False}
    return torch.amax(probs, 1), prop

def kl_calc(exp, model, dataset, n_mc):
    mc_probs = P._get_mc_probs(exp, model, dataset, n_mc)
    if mc_probs.size(0)!=n_mc:
        raise ValueError(f'mc_probs:{mc_probs.size(0)} is not n_mc:{n_mc}')
    prop = {'descending': False}
    label = mc_probs.argmax(dim=-1)
    kl, _ = computeKL(mc_probs.cpu().numpy(), mc_probs.size(2), label.cpu().numpy())
    return torch.from_numpy(kl), prop

def klp_calc(exp, model, dataset, n_mc):
    mc_probs = P._get_mc_probs(exp, model, dataset, n_mc)
    if mc_probs.size(0)!=n_mc:
        raise ValueError(f'mc_probs:{mc_probs.size(0)} is not n_mc:{n_mc}')
    prop = {'descending': False}
    result = mc_probs.cpu().numpy()
    label = mc_probs.argmax(dim=-1).cpu().numpy()
    kl, _ = computeKL(result, mc_probs.size(2), label)

    nb_bins = 50
    p,_ = prob_mean(result)
    dic, score, p, vbins, pbins = compute2DHistGroup(kl, p, nb_bins)
    res = []
    for i in range(nb_bins):
        vidx, pidx = i, i
        for n in range(pidx + 1):
            res.extend(dic[n][pidx])
        for h in range(vidx):
            res.extend(dic[vidx][h])

    indices = torch.tensor(res, dtype=int)
    rank = torch.zeros(indices.size(0), dtype=torch.int)
    rank[indices] = torch.arange(1, indices.size(0) + 1, dtype=torch.int)
    return rank, prop

def varp_calc(exp, model, dataset, n_mc):
    mc_probs = P._get_mc_probs(exp, model, dataset, n_mc)
    if mc_probs.size(0)!=n_mc:
        raise ValueError(f'mc_probs:{mc_probs.size(0)} is not n_mc:{n_mc}')
    prop = {'descending': False}
    result = mc_probs.cpu().numpy()

    #Sort variance
    var_all_class = np.var(result, axis=0)
    var_mean_all_class = np.mean(var_all_class, axis=1)
    p, _ = prob_mean(result)

    # select data by two dimesions output probability and the variance
    nb_bins = 50
    dic, score, p, vbins, pbins= compute2DHistGroup(var_mean_all_class, p, nb_bins)
    res = []
    for i in range(nb_bins)[::-1]:
        vidx, pidx = i, nb_bins-1-i
        for n in range(pidx+1):
            res.extend(dic[nb_bins-1-n][pidx])
        for h in range(pidx):
            res.extend(dic[nb_bins-1-pidx][h])

    indices = torch.tensor(res, dtype=int)
    rank = torch.zeros(indices.size(0), dtype=torch.int)
    rank[indices] = torch.arange(1, indices.size(0) + 1, dtype=torch.int)
    return rank, prop

def MCP(probs):
    selectsize = probs.size(0)
    act_layers = probs
    dicratio = [[] for i in range(100)]
    dicindex = [[] for i in range(100)]
    for i in range(len(act_layers)):
        act=act_layers[i]
        max_index,sec_index,ratio =find_second(act)#max_index 
        dicratio[max_index*10+sec_index].append(ratio)
        dicindex[max_index*10+sec_index].append(i)
        # print(i, max_index,sec_index,ratio)

    selected_lst = select_from_firstsec_dic(selectsize,dicratio,dicindex)
    indices = torch.tensor(selected_lst, dtype=int)
    rank = torch.zeros(indices.size(0), dtype=torch.int)
    rank[indices] = torch.arange(1, indices.size(0) + 1, dtype=torch.int)
    return rank

def find_second(act):
    max_=0
    second_max=0
    sec_index=0
    max_index=0
    for i in range(10):
        if act[i]>max_:
            max_=act[i]
            max_index=i
            
    for i in range(10):
        if i==max_index:
            continue
        if act[i]>second_max:
            second_max=act[i]
            sec_index=i
    ratio=1.0*second_max/max_
    #print 'max:',max_index
    return max_index,sec_index,ratio

def select_from_firstsec_dic(selectsize,dicratio,dicindex):
    selected_lst=[]
    tmpsize=selectsize
    
    noempty=no_empty_number(dicratio)
    # print(selectsize)
    # print(noempty)
    while (noempty>0) and (selectsize>=noempty):
        print(selectsize)
        print(noempty)
        for i in range(100):
            if len(dicratio[i])!=0:
                tmp=max(dicratio[i])
                j = dicratio[i].index(tmp)
                # if tmp>=0.1:
                selected_lst.append(dicindex[i][j])
                dicratio[i].remove(tmp)
                dicindex[i].remove(dicindex[i][j])
        selectsize=tmpsize-len(selected_lst)
        noempty=no_empty_number(dicratio)

    while len(selected_lst)!= tmpsize:
        max_tmp=[0 for i in range(selectsize)]
        max_index_tmp=[0 for i in range(selectsize)]
        for i in range(100):
            if len(dicratio[i])!=0:
                tmp_max=max(dicratio[i])
                if tmp_max>min(max_tmp):
                    index=max_tmp.index(min(max_tmp))
                    max_tmp[index]=tmp_max
                    #selected_lst.append()
                    #if tmp_max>=0.1:
                    max_index_tmp[index]=dicindex[i][dicratio[i].index(tmp_max)]
        if len(max_index_tmp)==0 and len(selected_lst)!= tmpsize:
            print('wrong!!!!!!')  
            break
        selected_lst=selected_lst+ max_index_tmp
    #print(selected_lst)
    assert len(selected_lst)== tmpsize
    return selected_lst

def no_empty_number(dicratio):
    no_empty=0
    for i in range(len(dicratio)):
        if len(dicratio[i])!=0:
            no_empty+=1
    return no_empty

def MCP_calc(exp, model, dataset):
    probs = P._get_probs(exp, model, dataset)
    prop = {'descending': False}
    return MCP(probs), prop

def _find_metric(metric_name):
    return getattr(sys.modules[__name__], metric_name + '_calc')