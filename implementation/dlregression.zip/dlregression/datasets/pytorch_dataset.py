import os
import torch
import torchvision
import torchvision.transforms as transforms
from easydict import EasyDict

__all__ = ['MNIST', 'FashionMNIST', 'CIFAR10', 'SVHN']

DOWNLOAD_DEFAULT = True

def MNIST(path, download=DOWNLOAD_DEFAULT):
    dataset = EasyDict({
        'train': torchvision.datasets.MNIST(root=path, train=True, download=download),
        'test': torchvision.datasets.MNIST(root=path, train=False, download=download),
    })
    classes = dataset.test.classes
    return dataset, classes

def FashionMNIST(path, download=DOWNLOAD_DEFAULT):
    dataset = EasyDict({
        'train': torchvision.datasets.FashionMNIST(root=path, train=True, download=download),
        'test': torchvision.datasets.FashionMNIST(root=path, train=False, download=download),
    })
    classes = dataset.test.classes
    return dataset, classes

def CIFAR10(path, download=DOWNLOAD_DEFAULT):
    dataset = EasyDict({
        'train': torchvision.datasets.CIFAR10(root=path, train=True, download=download),
        'test': torchvision.datasets.CIFAR10(root=path, train=False, download=download)
    })
    classes = dataset.test.classes
    return dataset, classes

def SVHN(path, download=DOWNLOAD_DEFAULT):
    dataset = EasyDict({
        'train': torchvision.datasets.SVHN(root=path, split='train', download=download),
        'test': torchvision.datasets.SVHN(root=path, split='test', download=download)
    })
    classes = ['0 - zero', '1 - one', '2 - two', '3 - three', '4 - four',
               '5 - five', '6 - six', '7 - seven', '8 - eight', '9 - nine']
    return dataset, classes