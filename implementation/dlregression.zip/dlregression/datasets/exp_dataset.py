import torch.utils.data as data

__all__ = ['ExpDataset']

class ExpDataset(data.Dataset):
    def __init__(
        self, 
        dataset, 
        transforms = [], 
        target_transforms = []
    ) -> None:
        self.dataset = dataset
        self.transforms = transforms
        self.target_transforms = target_transforms

    def __getitem__(self, idx):
        data, target = self.dataset[idx]

        for transform in self.transforms:
            data = transform(data)

        for transform in self.target_transforms:
            target = transform(target)

        return data, target
    
    def __len__(self):
        return len(self.dataset)