import os
import torch
import numpy as np
import torch.utils.data as data
from PIL import Image
from torchvision import datasets
from easydict import EasyDict

subsets = ['brightness', 'elastic_transform', 'gaussian_blur', 'impulse_noise', 'motion_blur', 'shot_noise', 
            'speckle_noise', 'contrast', 'fog', 'gaussian_noise', 'jpeg_compression', 'pixelate', 'snow', 
            'zoom_blur', 'defocus_blur', 'frost', 'glass_blur', 'saturate', 'spatter']

class CIFAR10C(datasets.VisionDataset):
    def __init__(self, root: str, name: str, transforms = None, transform = None, target_transform = None) -> None:
        assert name in subsets
        super().__init__(root, transforms=transforms, transform=transform, target_transform=target_transform)
        self.loaded = False
        self.name = name
    
    def load(self):
        data_path = os.path.join(self.root, self.name + '.npy')
        target_path = os.path.join(self.root, 'labels.npy')
        self.data = np.load(data_path)
        self.targets = np.load(target_path).astype(np.int64)
        self.loaded = True

    def __getitem__(self, index):
        if not self.loaded:
            self.load()
        img, targets = self.data[index], self.targets[index]
        img = Image.fromarray(img)
        
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            targets = self.target_transform(targets)
            
        return img, targets
    
    def __len__(self):
        if not self.loaded:
            self.load()
        return len(self.data)    

class CIFAR10C_ALL(data.Dataset):
    def __init__(self, datasets) -> None:
        super().__init__()
        self.datasets = datasets

    def __getitem__(self, index):
        l1_idx = index // len(self.datasets[0])
        l2_idx = index % len(self.datasets[0])
        return self.datasets[l1_idx][l2_idx]
    
    def __len__(self):
        return len(self.datasets) * len(self.datasets[0])

def cifar10c(path, transform=None, target_transform=None):
    dataset = EasyDict()
    for ds in subsets:
        dataset[ds] = CIFAR10C(path, ds, transform=transform, target_transform=target_transform)
    dataset['cifar10c'] = CIFAR10C_ALL(list(dataset.values()))
    return dataset