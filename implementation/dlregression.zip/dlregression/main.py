
import os
import sys
import argparse
import analysis
from experiment import list_exp
from easydict import EasyDict as edict

env = edict()
source_root = os.path.dirname(os.path.abspath(__file__))
env.source_root = source_root
env.output_root = os.path.join(source_root, 'output')
env.result_root = os.path.join(source_root, 'result')
env.config_root = os.path.join(source_root, 'configs')
env.dataset_root = os.path.join(source_root, '.dataset_cache')
env.pretrained_root = os.path.join(source_root, '.pretrained')

def get_parser():
    """Get a CLI parser."""
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('config', nargs='*', help='experiment configurations')
    parser.add_argument('-a', '--analysis', help='analysis')
    return parser

def main(argv):
    """The main function"""
    parser = get_parser()
    opts = parser.parse_args(argv)
    exps = []

    if opts.analysis != None:
        analyze(env, opts)
        return 0

    for config in opts.config:
        exps += list_exp(env, config)
    for exp in exps:
        exp.do()
    return 0

def analyze(env, opts):
    func = getattr(analysis, opts.analysis)
    func(env, opts)

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
    # sys.exit(main(['test']))