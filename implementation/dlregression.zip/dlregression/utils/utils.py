import importlib

__all__ = ['get_module']

def get_module(name):
    components = name.split('.')
    length = len(components)
    for i in range(length, 0, -1):
        module_name = '.'.join(components[0:i])
        attr_name = '.'.join(components[i:])
        try:
            module = importlib.import_module(module_name)
        except ModuleNotFoundError:
            continue
        try:
            attr = getattr(module, attr_name)
        except AttributeError:
            continue
        return attr
    raise ValueError(f'{name} not exsit!')