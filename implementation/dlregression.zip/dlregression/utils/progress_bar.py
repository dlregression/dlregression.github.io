import sys
from tqdm import tqdm
__all__ = ['ProgressBar']

class ProgressBar(tqdm):
    def __init__(self, desc) -> None:
        super().__init__(
            desc=desc,
            initial=0,
            position=None,
            disable=False,
            leave=True,
            dynamic_ncols=True,
            file=sys.stdout,
            smoothing=0,
            ascii=True
        )