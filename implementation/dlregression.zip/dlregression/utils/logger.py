__all__ = ['Logger']

class Logger:
    def __init__(self) -> None:
        pass

    def log(self):
        pass