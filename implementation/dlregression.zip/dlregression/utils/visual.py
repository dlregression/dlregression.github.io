from plotly.subplots import make_subplots
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import torchvision.transforms.functional as F
from torchvision.utils import make_grid

def imshow(imgs, nrow, titles=[]):
    if not isinstance(imgs, list):
        imgs = [imgs]
    cols = nrow
    rows = (len(imgs) + nrow - 1) // nrow
    fig = make_subplots(rows=rows, cols=cols, subplot_titles=titles)
    for i, img in enumerate(imgs):
        img = img.detach()
        img = F.to_pil_image(img)
        fig.add_trace(px.imshow(np.asarray(img), binary_string=True).data[0], row=i//cols+1, col=i%cols+1)
    fig.show()