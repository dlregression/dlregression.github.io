import torch
import torch.nn as nn
__all__ = ['LeNet5', 'LeNet1']

class LeNet5(nn.Module):

    def __init__(self, input_shape, num_classes):
        super(LeNet5, self).__init__()
        c, h, w = input_shape
        self.feature_extractor = nn.Sequential(            
            nn.Conv2d(in_channels=c, out_channels=6, kernel_size=5, stride=1),
            nn.Tanh(),
            nn.AvgPool2d(kernel_size=2),
            nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1),
            nn.Tanh(),
            nn.AvgPool2d(kernel_size=2),
            nn.Conv2d(in_channels=16, out_channels=120, kernel_size=5, stride=1),
            nn.Tanh()
        )
        self.dropout = nn.Dropout()
        self.classifier = nn.Sequential(
            nn.Linear(in_features=120, out_features=84),
            nn.Tanh(),
            nn.Linear(in_features=84, out_features=num_classes),
        )

    def forward(self, x):
        x = self.feature_extractor(x)
        x = torch.flatten(x, 1)
        x = self.dropout(x)
        logits = self.classifier(x)
        return logits

class LeNet1(nn.Module):
    def __init__(self, input_shape, num_classes) -> None:
        super(LeNet1, self).__init__()
        c, h, w = input_shape
        fc_in = 12*(h//4-3)*(w//4-3)
        self.conv1 = nn.Sequential(
            nn.Conv2d(c, 4, 5, padding=0, bias=False),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(4, 12, 5, padding=0, bias=False),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )
        self.dropout = nn.Dropout()
        self.fc = nn.Linear(fc_in, num_classes)
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = torch.flatten(x, 1)
        x = self.dropout(x)
        logits = self.fc(x)

        return logits
