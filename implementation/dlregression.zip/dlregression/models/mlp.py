'''
    xubs
    MLP_3_hidden_layers
'''

import torch
import torch.nn as nn
import torch.nn.functional as F
__all__ = ['MLP']

class MLP(nn.Module):
    def __init__(self, input_shape, num_classes):
        super(MLP, self).__init__()
        c, h, w = input_shape

        num_inputs = c * h * w
        self.fc1 = torch.nn.Linear(num_inputs, 512)
        self.dropout1 = nn.Dropout(p=0.2)
        self.fc2 = torch.nn.Linear(512, 128)
        self.dropout2 = nn.Dropout(p=0.2)
        self.fc3 = torch.nn.Linear(128, num_classes)

    def forward(self, x):
        x = torch.flatten(x, 1)
        x = self.dropout1(x)
        x = F.relu(self.fc1(x))
        x = self.dropout2(x)
        x = F.relu(self.fc2(x))
        logits = self.fc3(x)

        return logits













