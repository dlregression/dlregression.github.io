import models

__all__ = ['model_parameters']



def model_parameters(env, opts):
    input_shape = (1, 32, 32)
    num_classes = 10
    md = models.LeNet1
    model = md(input_shape = input_shape, num_classes = num_classes)
    print('LeNet-1 1 Channel:')
    count(model)

    md = models.LeNet5
    model = md(input_shape = input_shape, num_classes = num_classes)
    print('LeNet-5 1 Channel:')
    count(model)

    input_shape = (3, 32, 32)
    md = models.LeNet5
    model = md(input_shape = input_shape, num_classes = num_classes)
    print('LeNet-5 3 Channel:')
    count(model)

    md = models.resnet18
    model = md(input_shape = input_shape, num_classes = num_classes)
    print('ReNet-18 3 Channel:')
    count(model)

def count(model):
    # Find total parameters and trainable parameters
    total_params = sum(p.numel() for p in model.parameters())
    print(f'{total_params:,} total parameters.')
    total_trainable_params = sum(
        p.numel() for p in model.parameters() if p.requires_grad)
    print(f'{total_trainable_params:,} training parameters.')