from functools import cmp_to_key
import os
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import datasets
from plotly.subplots import make_subplots
from experiment import list_exp
from experiments import private as P

__all__ = ['regression_reduction']

datasets = ['test']
scores = [('nfr', P._nfr_path), ('nfr_rel', P._nfr_rel_path), ('nfr_rel_1', P._nfr_rel_1_path), ('btc', P._btc_path), ('bec', P._bec_path)]
legend_map = {
    ('distill', 'm1'): {'text': r'Vanilla Cross Entropy', 'color': 'red', 'marker': 0},
    ('distill', 'm2'): {'text': r'FD1', 'color': 'orange', 'marker': 1},
    ('distill', 'm3'): {'text': r'KD1', 'color': 'darkgreen', 'marker': 2},
    ('distill', 'm4'): {'text': r'FD2', 'color': 'olive', 'marker': 3},
    ('distill', 'm5'): {'text': r'KD2', 'color': 'darkorange', 'marker': 4},
    ('label_smoothing', 'm1'): {'text': r'LS1', 'color': 'deepskyblue', 'marker': 5},
    ('label_smoothing1', 'm1'): {'text': r'LS2', 'color': 'mediumblue', 'marker': 6},
    ('mixup', 'm1'): {'text': r'Mixup1', 'color': 'darkgray', 'marker': 7},
    ('mixup2', 'm1'): {'text': r'Mixup2', 'color': 'darkcyan', 'marker': 8},
}

fixup_map = {
    'MNIST': 'MNIST',
    'FashionMNIST': 'Fashion-MNIST',
    'SVHN': 'SVHN',
    'CIFAR10': 'CIFAR-10',
    'LeNet1': 'LeNet-1',
    'LeNet5': 'LeNet-5',
    'resnet18': 'ResNet-18'
}

ds_seq = ['MNIST', 'Fashion-MNIST', 'SVHN', 'CIFAR-10']
mod_seq = ['LeNet-1', 'LeNet-5', 'ResNet-18']

def regression_reduction(env, opts):
    result_path = os.path.join(env.result_root, 'regression_reduction')
    if not os.path.exists(result_path):
        os.makedirs(result_path)
    exps = list_exp(env, 'regression_reduction')
    dfs_cache = {}
    for experiment in exps:
        _, dataset, aug, method = experiment.config.name.split('/')        
        for exp in experiment.each_exp():
            print(dataset, aug, method, exp.id)
            # negative_flip_statis(exp)
            for ds in datasets:
                df_acc = analysis_acc(exp, ds, method)
                update_df(dfs_cache, dataset, aug, exp.id, 'acc', df_acc)
                for name, path_func in scores:
                    df, df_step = analysis_score(exp, ds, method, path_func)
                    update_df(dfs_cache, dataset, aug, exp.id, name, df)
                    update_df(dfs_cache, dataset, aug, exp.id, f'{name}_step', df_step)

    df = do_mean(dfs_cache, 'acc', 'margin')
    df.to_csv(os.path.join(result_path, 'mean_acc_margin.csv'))
    df = do_mean(dfs_cache, 'acc', 'random')
    df.to_csv(os.path.join(result_path, 'mean_acc_random.csv'))

    df = do_mean(dfs_cache, 'nfr_step', 'margin')
    df.to_csv(os.path.join(result_path, 'mean_nfr_step_margin.csv'))
    df = do_mean(dfs_cache, 'nfr_step', 'random')
    df.to_csv(os.path.join(result_path, 'mean_nfr_step_random.csv'))

    df = do_mean(dfs_cache, 'nfr_rel_step', 'margin')
    df.to_csv(os.path.join(result_path, 'mean_nfr_rel_step_margin.csv'))
    df = do_mean(dfs_cache, 'nfr_rel_step', 'random')
    df.to_csv(os.path.join(result_path, 'mean_nfr_rel_step_random.csv'))

    # df = do_mean(dfs_cache, 'nfr_rel_1_step', 'margin')
    # df.to_csv(os.path.join(result_path, 'mean_nfr_rel_1_step_margin.csv'))
    # df = do_mean(dfs_cache, 'nfr_rel_1_step', 'random')
    # df.to_csv(os.path.join(result_path, 'mean_nfr_rel_1_step_random.csv'))
    # for (dataset, aug, id), dfs in dfs_cache.items():
    #     for name, df in dfs.items():
    #         if df.empty:
    #             continue
    #         dir = os.path.join(result_path, f'{dataset}_{aug}')
    #         if not os.path.exists(dir):
    #             os.makedirs(dir)
    #         path = os.path.join(dir, f'{id}_{name}.csv')
    #         df.to_csv(path)
    #         plot(df, id, name, dir)

    fig = plot_in_one(dfs_cache, 'margin')
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-margin.pdf'))
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-margin.png'))
    fig = plot_in_one(dfs_cache, 'random')
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-random.pdf'))
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-random.png'))

    fig = plot_in_one(dfs_cache, 'margin', True)
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-margin-noaug.pdf'))
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-margin-noaug.png'))
    fig = plot_in_one(dfs_cache, 'random', True)
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-random-noaug.pdf'))
    fig.write_image(os.path.join(result_path, 'acc-rel_nfr-random-noaug.png'))

def try_read_csv(*args, **kwargs):
    try:
        df = pd.read_csv(*args, **kwargs)
    except FileNotFoundError:
        return None
    return df

def get_df(cache, dataset, aug, id, name):
    if (dataset, aug, id) not in cache:
        return None
    dfs = cache[(dataset, aug, id)]
    if name not in dfs:
        return None
    return dfs[name]

def set_df(cache, dataset, aug, id, name, df):
    if (dataset, aug, id) not in cache:
        cache[(dataset, aug, id)] = {}
    dfs = cache[(dataset, aug, id)]
    dfs[name] = df

def update_df(cache, dataset, aug, id, name, df):
    old_df = get_df(cache, dataset, aug, id, name)
    if old_df is None:
        new_df = df
    else:
        new_df = old_df.join(df)
    set_df(cache, dataset, aug, id, name, new_df)

def analysis_model(df, search_index=False, search_columns=False):
    if df is None:
        return {}
    seq_max = {}
    if search_index:
        for index in df.index:
            idx = index.split('.')
            if len(idx) == 1:
                base_model = index
                continue
            model, metric, seq = idx
            seq = int(seq)
            key = (model, metric)
            if (key not in seq_max) or (seq_max[key] < seq):
                seq_max[key] = seq
    if search_columns:
        for index in df.columns:
            idx = index.split('.')
            if len(idx) == 1:
                base_model = index
                continue
            model, metric, seq = idx
            seq = int(seq)
            key = (model, metric)
            if (key not in seq_max) or (seq_max[key] < seq):
                seq_max[key] = seq
    sequnces = {}
    for key, max in seq_max.items():
        seq = [base_model] + [f'{".".join(key)}.{i}' for i in range(max + 1)]
        sequnces[key] = seq
    return sequnces

def analysis_acc(exp, ds, method):
    data_frame = try_read_csv(P._accuracy_path(exp), index_col=0)
    df = pd.DataFrame(columns=pd.MultiIndex(levels=[[]]*3, codes=[[]]*3, names=['method', 'model', 'metric']))
    for (model, metric), seq in analysis_model(data_frame, search_index=True, search_columns=False).items():
        for i in range(len(seq)):
            df.loc[i, (method, model, metric)] = data_frame.loc[seq[i], ds]
    return df

def analysis_score(exp, ds, method, path_func):
    data_frame = try_read_csv(path_func(exp, ds), index_col=0)
    df = pd.DataFrame(columns=pd.MultiIndex(levels=[[]]*3, codes=[[]]*3, names=['method', 'model', 'metric']))
    df_step = pd.DataFrame(columns=pd.MultiIndex(levels=[[]]*3, codes=[[]]*3, names=['method', 'model', 'metric']))
    for (model, metric), seq in analysis_model(data_frame, search_index=True, search_columns=True).items():
        for i in range(1, len(seq)):
            df.loc[i, (method, model, metric)] = data_frame.loc[seq[0], seq[i]]
            df_step.loc[i, (method, model, metric)] = data_frame.loc[seq[i-1], seq[i]]
    return df, df_step

def plot(df, id, name, dir):
    dataset = id.split('.')[0]
    net = id.split('.')[1]
    for metric in set(df.columns.get_level_values('metric')):
        fig = go.Figure()
        fig.update_layout(
            title=dict(
                text=f'{name} {metric} {dataset} {net}'
            ),
        )
        df_metric = df.loc[:,(slice(None), slice(None), metric)]
        for i, (method, model, metric) in enumerate(df_metric.columns):
            legend = legend_map[(method, model)]
            fig.add_trace(
                go.Scatter(
                    x=df_metric.index,
                    y=df_metric[(method, model, metric)],
                    mode='lines+markers',
                    line_color=legend['color'],
                    marker_symbol=legend['marker'],
                    name=legend['text']
                )
            )
        path = os.path.join(dir, f'{id}_{metric}_{name}.png')
        fig.write_image(path)
        # fig.show()

def negative_flip_statis(exp):
    for ds in datasets:
        data_frame = try_read_csv(P._prediction_path(exp, ds), index_col=0)
        if data_frame is None:
            continue
        truth = data_frame.loc[:, 'ground_truth']
        df = data_frame.loc[:, ~data_frame.columns.isin(['ground_truth'])]
        for (model, metric), seq in analysis_model(df, search_index=False, search_columns=True).items():
            correct = pd.DataFrame()
            statis = pd.DataFrame()
            statis['negative_flip'] = np.zeros(len(df.index), int)
            for i in range(0, len(seq)):
                correct[i] = (df[seq[i]] == truth)
            for i in range(1, len(correct.columns)):
                statis.loc[(correct[i-1])&(~correct[i]), 'negative_flip'] += 1
            print(truth[statis['negative_flip'] != 0].value_counts())
            
class subplot_pos:
    def __init__(self, rows, cols) -> None:
        self.rows = rows
        self.cols = cols
        self.row = 1
        self.col = 1

    def next_pos(self):
        row = self.row
        col = self.col
        self.col += 1
        if self.col > self.cols:
            self.col = 1
            self.row += 1
        return row, col

def fix_key(x):
    dataset, aug, id = x
    s = id.split('.')
    ds = fixup_map[s[0]]
    model = fixup_map[s[1]]
    return ds, model, aug

def keys_cmp(x, y):
    x_ds, x_model, x_aug = fix_key(x)
    y_ds, y_model, y_aug = fix_key(y)
    if x_ds != y_ds:
        return ds_seq.index(x_ds) - ds_seq.index(y_ds)
    if x_model != y_model:
        return mod_seq.index(x_model) - mod_seq.index(y_model)
    return len(x_aug) - len(y_aug)

def plot_in_one(dfs_cache, metric, exclude_aug = False):
    keys = dfs_cache.keys()
    keys = sorted(keys, key=cmp_to_key(keys_cmp))
    subplot_titles = []
    for key in keys:
        ds, model, aug = fix_key(key)
        title = f'{ds}/{model}'
        if aug == 'aug':
            if exclude_aug:
                continue
            w = 'w DA'
        else:
            w = 'w/o DA'
        if not exclude_aug:
            title += f' {w}'
        subplot_titles.append(title)
        subplot_titles.append(title)
        subplot_titles.append(title)
    cols = 3
    rows = (len(subplot_titles) + cols - 1) // cols
    fig = make_subplots(rows=rows, cols=cols, subplot_titles=subplot_titles, vertical_spacing = 0.05)
    pos = subplot_pos(rows, cols)
    for (dataset, aug, id) in keys:
        if aug == 'aug' and exclude_aug:
            continue
        dfs = dfs_cache[(dataset, aug, id)]
        df = dfs['acc']
        if df.empty:
            continue
        df_metric = df.loc[:,(slice(None), slice(None), metric)]
        row, col = pos.next_pos()
        plot_subfig(df_metric, fig, row, col)
        fig.update_xaxes(title_text=r'$Step$', tickvals=df_metric.index, row = row, col = col)
        fig.update_yaxes(title_text=r'$ACC$', row = row, col = col)

        df = dfs['nfr_step']
        df_metric = df.loc[:,(slice(None), slice(None), metric)]
        row, col = pos.next_pos()
        plot_subfig(df_metric, fig, row, col)
        fig.update_xaxes(title_text=r'$Step$', tickvals=df_metric.index, row = row, col = col)
        fig.update_yaxes(title_text=r'$NFR$', row = row, col = col)

        df = dfs['nfr_rel_step']
        df_metric = df.loc[:,(slice(None), slice(None), metric)]
        row, col = pos.next_pos()
        plot_subfig(df_metric, fig, row, col)
        fig.update_xaxes(title_text=r'$Step$', tickvals=df_metric.index, row = row, col = col)
        fig.update_yaxes(title_text=r'$NFR_{rel}$', row = row, col = col)

    fig.update_layout(
        legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="center",
        x=0.5),
        autosize=False,
        width=1600,
        height=2500,
        margin=dict(
            l=10,
            r=10,
            b=20,
            t=20,
            pad=4
        ),
    )
    return fig

def plot_subfig(df_metric, fig, row, col):
    showlegend = False
    if row==1 and col==1:
        showlegend = True
    for method, model, metric in df_metric.columns:
        legend = legend_map[(method, model)]
        fig.add_trace(
            go.Scatter(
                x=df_metric.index,
                y=df_metric[(method, model, metric)],
                mode='lines+markers',
                line_color=legend['color'],
                marker_symbol=legend['marker'],
                name=legend['text'],
                legendgroup=legend['text'],
                showlegend=showlegend
            ),
            row=row,
            col=col
        )

def do_mean(dfs_cache, score, metric):
    target_df = pd.DataFrame()
    keys = dfs_cache.keys()
    for (dataset, aug, id) in keys:
        dfs = dfs_cache[(dataset, aug, id)]
        df = dfs[score]
        if df.empty:
            continue
        df_metric = df.loc[:,(slice(None), slice(None), metric)]
        target_df[f'{id}_{aug}'] = df_metric.mean()
    return target_df.T
