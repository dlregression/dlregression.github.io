from functools import cmp_to_key
import os
import numpy as np
import pandas as pd
from pandas.core.frame import DataFrame
import plotly.graph_objects as go
import datasets
from numpy import trapz
from experiment import list_exp
from experiments import private as P
from .regression_reduction import analysis_acc, update_df, analysis_score, fixup_map, ds_seq, mod_seq

__all__ = ['regression']

datasets = ['test']
scores = [('nfr', P._nfr_path), ('nfr_rel', P._nfr_rel_path), ('nfr_rel_1', P._nfr_rel_1_path), ('btc', P._btc_path), ('bec', P._bec_path)]
legend_map = {
    'm1': 'cross entropy',
    'm2': 'distill',
}

def regression(env, opts):
    result_path = os.path.join(env.result_root, 'regression')
    if not os.path.exists(result_path):
        os.makedirs(result_path)
    exps = list_exp(env, 'regression')
    dfs_cache = {}
    aug = 'noaug'
    method = 'distill'
    for experiment in exps:
        _, dataset = experiment.config.name.split('/')        
        for exp in experiment.each_exp():
            print(dataset, exp.id)
            # negative_flip_statis(exp)
            for ds in datasets:
                df_acc = analysis_acc(exp, ds, method)
                df_er = 100 - df_acc
                update_df(dfs_cache, dataset, aug, exp.id, 'acc', df_acc)
                update_df(dfs_cache, dataset, aug, exp.id, 'er', df_er)
                for name, path_func in scores:
                    df, df_step = analysis_score(exp, ds, method, path_func)
                    update_df(dfs_cache, dataset, aug, exp.id, name, df)
                    update_df(dfs_cache, dataset, aug, exp.id, f'{name}_step', df_step)

    # for (dataset, aug, id), dfs in dfs_cache.items():
    #     for name, df in dfs.items():
    #         if df.empty:
    #             continue
    #         dir = os.path.join(result_path, f'{dataset}_{aug}')
    #         if not os.path.exists(dir):
    #             os.makedirs(dir)
    #         path = os.path.join(dir, f'{id}_{name}.csv')
    #         df.to_csv(path)
    #         plot(df, id, name, dir)
    
    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr_step']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'random_nfr_step.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_nfr_step_box.pdf')
    fig.update_layout(
        legend=dict(
        # orientation="h",
        yanchor="top",
        y=1,
        xanchor="left",
        x=0,
        bgcolor='rgba(0,0,0,0)'
        ),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        autosize=False,
        margin=dict(
            l=10,
            r=10,
            b=20,
            t=20,
            pad=4
        ),
    ) 
    fig.update_yaxes(title_text=r'$NFR$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_nfr_step_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_nfr_step_avg_line.pdf')
    fig.update_xaxes(title_text=r'$Step$')
    fig.update_yaxes(title_text=r'$NFR$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    target_df = np.log(target_df)
    target_df.to_csv(os.path.join(result_path, 'random_nfr_log_step.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_nfr_log_step_box.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_nfr_log_step_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_nfr_log_step_avg_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['acc']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'acc.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_acc_box.pdf')
    fig.update_layout(
        legend=dict(
        # orientation="h",
        yanchor="bottom",
        y=0,
        xanchor="left",
        x=0,
        bgcolor='rgba(0,0,0,0)'
        ),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        autosize=False,
        margin=dict(
            l=10,
            r=10,
            b=20,
            t=20,
            pad=4
        ),
    ) 
    fig.update_yaxes(title_text=r'$ACC$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_acc_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_acc_avg_line.pdf')
    fig.update_xaxes(title_text=r'$Step$')
    fig.update_yaxes(title_text=r'$ACC$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['er']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'er.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_er_box.pdf')
    fig.update_yaxes(title_text=r'$ER$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_er_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_er_avg_line.pdf')
    fig.update_xaxes(title_text=r'$Step$')
    fig.update_yaxes(title_text=r'$ER$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr_rel_step']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'random_nfr_rel_step.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_nfr_rel_step_box.pdf')
    fig.update_yaxes(title_text=r'$NFR_{rel}$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_nfr_rel_step_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_nfr_rel_step_avg_line.pdf')
    fig.update_xaxes(title_text=r'$Step$')
    fig.update_yaxes(title_text=r'$NFR_{rel}$')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr_rel_1_step']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'random_nfr_rel_1_step.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_nfr_rel_1_step_box.pdf')
    fig.update_yaxes(title_text=r"$NFR_{rel}^{'}$")
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_nfr_rel_1_step_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_nfr_rel_1_step_avg_line.pdf')
    fig.update_xaxes(title_text=r'$Step$')
    fig.update_yaxes(title_text=r"$NFR_{rel}^{'}$")
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['btc_step']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'random_btc_step.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_btc_step_box.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_btc_step_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_btc_step_avg_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['bec_step']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'random_bec_step.csv'))
    fig = plot_box(target_df)
    path = os.path.join(result_path, f'random_bec_step_box.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    fig = plot_line(target_df)
    path = os.path.join(result_path, f'random_bec_step_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))
    avg_df = ds_mod_mean(target_df)
    fig = plot_line(avg_df)
    path = os.path.join(result_path, f'random_bec_step_avg_line.pdf')
    fig.write_image(path)
    fig.write_image(path.replace('.pdf', '.png'))

    frames = []
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr']
        frames.append(pd.DataFrame({id: df[('distill', 'm1', 'random')]}))
    target_df = pd.concat(frames, axis=1)
    target_df.to_csv(os.path.join(result_path, 'random_nfr.csv'))

    target_df = pd.DataFrame()
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr_step']
        target_df[id] = df.loc[:,('distill', 'm1', slice(None))].mean()
    target_df.T.to_csv(os.path.join(result_path, 'mean_nfr_step.csv'))

    target_df = pd.DataFrame()
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr_rel_step']
        target_df[id] = df.loc[:,('distill', 'm1', slice(None))].mean()
    target_df.T.to_csv(os.path.join(result_path, 'mean_nfr_rel_step.csv'))
    # fig = plot_heatmap(target_df.T)
    # path = os.path.join(result_path, f'mean_nfr_rel_step_heat.pdf')
    # fig.write_image(path)
    # fig.write_image(path.replace('.pdf', '.png'))

    target_df = pd.DataFrame()
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr_rel_1_step']
        target_df[id] = df.loc[:,('distill', 'm1', slice(None))].mean()
    target_df.T.to_csv(os.path.join(result_path, 'mean_nfr_rel_1_step.csv'))

    target_df = pd.DataFrame()
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['nfr_rel']
        target_df[id] = df.loc[:,('distill', 'm1', slice(None))].mean()
    target_df.T.to_csv(os.path.join(result_path, 'mean_nfr_rel.csv'))

    target_df = pd.DataFrame()
    for (dataset, aug, id), dfs in dfs_cache.items():
        df = dfs['acc']
        target_df[id] = df.loc[:,('distill', 'm1', slice(None))].mean()
    target_df.T.to_csv(os.path.join(result_path, 'mean_acc.csv'))
    # fig = plot_heatmap(target_df.T)
    # path = os.path.join(result_path, f'mean_acc_heat.pdf')
    # fig.write_image(path)
    # fig.write_image(path.replace('.pdf', '.png'))
    
def plot(df, id, name, dir):
    dataset = id.split('.')[0]
    net = id.split('.')[1]
    for model in set(df.columns.get_level_values('model')):
        fig = go.Figure()
        fig.update_layout(
            title=dict(
                text=f'{name} {legend_map[model]} {dataset} {net}'
            ),
        )
        df_model = df.loc[:,(slice(None), model, slice(None))]
        for i, (method, model, metric) in enumerate(df_model.columns):
            fig.add_trace(
                go.Scatter(
                    x=df_model.index,
                    y=df_model[(method, model, metric)],
                    mode='lines+markers',
                    marker_symbol=i,
                    name=metric
                )
            )
        path = os.path.join(dir, f'{id}_{model}_{name}.pdf')
        fig.write_image(path)
        fig.write_image(path.replace('.pdf', '.png'))

def keys_cmp(x ,y):
    x_ds, x_model = x
    y_ds, y_model = y
    if x_ds != y_ds:
        return ds_seq.index(x_ds) - ds_seq.index(y_ds)
    if x_model != y_model:
        return mod_seq.index(x_model) - mod_seq.index(y_model)
    return 0

def plot_box(df:DataFrame, showlegend=True):
    data_map = {}
    fig = go.Figure()
    for col in df.columns:
        s = col.split('.')
        ds = fixup_map[s[0]]
        mod = fixup_map[s[1]]
        if (ds, mod) not in data_map:
            data_map[(ds, mod)] = []
        data_map[(ds, mod)] += df[col].dropna().to_list()
    keys = sorted(data_map.keys(), key=cmp_to_key(keys_cmp))
    for (ds, mod) in keys:
        data = data_map[(ds, mod)]
        fig.add_trace(go.Box(
            y=data, 
            quartilemethod="linear", 
            name=f'{ds}/{mod}',
            showlegend=showlegend
            )
        )
    fig.update_layout(
        legend=dict(
        # orientation="h",
        yanchor="bottom",
        y=0,
        xanchor="right",
        x=1,
        bgcolor='rgba(0,0,0,0)'
        ),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        autosize=False,
        margin=dict(
            l=10,
            r=10,
            b=20,
            t=20,
            pad=4
        ),
    ) 
    return fig

def plot_line(df:DataFrame, showlegend=True):
    data_map = {}
    fig = go.Figure()
    fig.update_xaxes(tickvals=df.index)
    for col in df.columns:
        s = col.split('.')
        ds = fixup_map[s[0]]
        mod = fixup_map[s[1]]
        data_map[(ds, mod)] = df[col].dropna()
    keys = sorted(data_map.keys(), key=cmp_to_key(keys_cmp))
    for i, (ds, mod) in enumerate(keys):
        data = data_map[(ds, mod)]
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data,
                mode='lines+markers',
                marker_symbol=i,
                name=f'{ds}/{mod}',
                showlegend=showlegend
            )
        )
    fig.update_layout(
        legend=dict(
        # orientation="h",
        yanchor="top",
        y=1,
        xanchor="right",
        x=1,
        bgcolor='rgba(0,0,0,0)'
        ),
        autosize=False,
        margin=dict(
            l=10,
            r=10,
            b=20,
            t=20,
            pad=4
        ),
    ) 
    return fig

def plot_heatmap(df:DataFrame):
    df = df.round(2)
    z = df.rank(axis=1)
    print(z)
    x = []
    for col in df.columns:
        x += ['.'.join(col)]
    y = df.index
    print(x)
    fig = go.Figure(data=go.Heatmap(
                    z=z,
                    text=df,
                    x=x,
                    y=y,
                    type = 'heatmap',
                    colorscale = 'Viridis',
                    texttemplate="%{text}",
                    textfont={"size":10}))
    fig.update_layout(
        legend=dict(
        # orientation="h",
        yanchor="top",
        y=1,
        xanchor="right",
        x=1,
        bgcolor='rgba(0,0,0,0)'
        ),
        autosize=False,
        margin=dict(
            l=10,
            r=10,
            b=20,
            t=20,
            pad=4
        ),
    ) 
    # fig.show()
    return fig

def ds_mod_mean(df:DataFrame):
    data_map = {}
    for col in df.columns:
        s = col.split('.')
        ds = s[0]
        mod = s[1]
        if (ds, mod) not in data_map:
            data_map[(ds, mod)] = pd.DataFrame()
        data_map[(ds, mod)][col] = df[col]
    avg_df = pd.DataFrame()
    for (ds, mod), df in data_map.items():
        avg_df[f'{ds}.{mod}'] = df.mean(axis=1)
    return avg_df