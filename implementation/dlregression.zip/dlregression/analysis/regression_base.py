from functools import cmp_to_key
import os
import numpy as np
import pandas as pd
from pandas.core.frame import DataFrame
import plotly.graph_objects as go
import datasets
from numpy import trapz
from experiment import list_exp
from experiments import private as P
from .regression_reduction import try_read_csv

__all__ = ['regression_base']

def regression_base(env, opts):
    result_path = os.path.join(env.result_root, 'regression_base')
    if not os.path.exists(result_path):
        os.makedirs(result_path)
    exps = list_exp(env, 'regression_base')
    nfr_list = []
    nfr_rel_list = []
    clever_df = pd.DataFrame()
    churn_df = pd.DataFrame()
    clever_map = {}
    for experiment in exps:
        _, dataset = experiment.config.name.split('/')        
        for exp in experiment.each_exp():
            # df = statis(exp, P._nfr_path)
            # nfr_list.append((exp.id, df))
            # df = statis(exp, P._nfr_rel_path)
            # nfr_rel_list.append((exp.id, df))
            flip_statis(exp, clever_df, clever_map)
            # churn_statis(exp, churn_df)
    
    # clever_df.to_csv(os.path.join(result_path, 'mean_clever.csv'))
    fig = plot_clever(clever_map)
    path = os.path.join(result_path, f'clever_box.pdf')
    fig.update_layout(
        # legend=dict(
        # # orientation="h",
        # yanchor="top",
        # y=1,
        # xanchor="left",
        # x=0,
        # bgcolor='rgba(0,0,0,0)'
        # ),
        autosize=False,
        width=1500,
        height=400,
        margin=dict(
            l=10,
            r=10,
            b=20,
            t=20,
            pad=4
        ),
    ) 
    fig.write_image(path)
    # churn_df.to_csv(os.path.join(result_path, 'churn.csv'))


    # print('nfr:')
    # for id, df in nfr_list:
    #     print(id)
    #     print(df)

    # print('nfr_rel:')
    # for id, df in nfr_rel_list:
    #     print(id)
    #     print(df)

def statis(exp, path_func):
    data_frame = try_read_csv(path_func(exp, 'test'), index_col=0)
    df = pd.DataFrame()
    for i in range(1, 10):
        m = f'm1.random.{i}'
        if m in data_frame.columns:
            if i == 1:
                prev_m = 'm0'
            else:
                prev_m = f'm1.random.{i-1}'
            df.loc[f'step {i}:', 'normal'] = data_frame.loc[prev_m, m]
            df.loc[f'step {i}:', 'inherent_1'] = data_frame.loc[m, m+'.1']
            df.loc[f'step {i}:', 'inherent_2'] = data_frame.loc[m, m+'.2']
            df.loc[f'step {i}:', 'delta_1'] = data_frame.loc[prev_m, m] - data_frame.loc[m, m+'.1']
            df.loc[f'step {i}:', 'delta_2'] = data_frame.loc[prev_m, m] - data_frame.loc[m, m+'.2']
            df.loc[f'step {i}:', 'delta_mean'] = data_frame.loc[prev_m, m] - ((data_frame.loc[m, m+'.1'] +data_frame.loc[m, m+'.2'])/2)
    return df


def flip_statis(exp, dfs, clever_map):
    data_frame = try_read_csv(P._prediction_path(exp, 'test'), index_col=0)
    clever_df = try_read_csv(P._clever_path(exp, 'test'), index_col=0)
    if (data_frame is None) or (clever_df is None):
        return
    truth = data_frame.loc[:, 'ground_truth']
    # df = data_frame.loc[:, ~data_frame.columns.isin(['ground_truth'])]
    
    for i in range(1, 10):
        m = f'm1.random.{i}'
        if m not in clever_df.columns:
            continue
        if m in data_frame.columns:
            if i == 1:
                prev_m = 'm0'
            else:
                prev_m = f'm1.random.{i-1}'
            pf_df = data_frame[(data_frame[prev_m]!=truth)&(data_frame[m]==truth)]
            nf_df = data_frame[(data_frame[prev_m]==truth)&(data_frame[m]!=truth)]
            all_flip_df = data_frame[(data_frame[prev_m] != data_frame[m])]
            all_right_df = data_frame[(data_frame[prev_m]==truth)&(data_frame[m]==truth)]
            all_wrong_df = data_frame[(data_frame[prev_m]!=truth)&(data_frame[m]!=truth)]

            dfs.loc[f'{exp.id}/{m}', 'nf_1'] = clever_df.loc[nf_df.index][prev_m].mean()
            dfs.loc[f'{exp.id}/{m}', 'nf_2'] = clever_df.loc[nf_df.index][m].mean()
            dfs.loc[f'{exp.id}/{m}', 'pf_1'] = clever_df.loc[pf_df.index][prev_m].mean()
            dfs.loc[f'{exp.id}/{m}', 'pf_2'] = clever_df.loc[pf_df.index][m].mean()  
            dfs.loc[f'{exp.id}/{m}', 'all_flip_1'] = clever_df.loc[all_flip_df.index][prev_m].mean()
            dfs.loc[f'{exp.id}/{m}', 'all_flip_2'] = clever_df.loc[all_flip_df.index][m].mean()  
            dfs.loc[f'{exp.id}/{m}', 'all_right_1'] = clever_df.loc[all_right_df.index][prev_m].mean()
            dfs.loc[f'{exp.id}/{m}', 'all_right_2'] = clever_df.loc[all_right_df.index][m].mean()   
            dfs.loc[f'{exp.id}/{m}', 'all_wrong_1'] = clever_df.loc[all_wrong_df.index][prev_m].mean()
            dfs.loc[f'{exp.id}/{m}', 'all_wrong_2'] = clever_df.loc[all_wrong_df.index][m].mean()
            clever_map[(exp.id, i, 'nf_1')] = clever_df.loc[nf_df.index][prev_m]
            clever_map[(exp.id, i, 'all_right_1')] = clever_df.loc[all_right_df.index][prev_m]

def calc_churn(pred_df, m):
    churn0 = set()
    churn1 = set()
    churn2 = set()
    m1 = m + '.1'
    m2 = m + '.2'
    churn_df = pred_df[(pred_df[m]!=pred_df[m1])]
    churn0.update(churn_df.index.values.tolist())
    churn_df = pred_df[(pred_df[m]!=pred_df[m2])]
    churn1.update(churn_df.index.values.tolist())
    churn_df = pred_df[(pred_df[m1]!=pred_df[m2])]
    churn2.update(churn_df.index.values.tolist())
    return churn0, churn1, churn2

def churn_statis(exp, df):
    data_frame = try_read_csv(P._prediction_path(exp, 'test'), index_col=0)
    truth = data_frame.loc[:, 'ground_truth']
    churn_list = []
    nf_list = []
    for i in range(1, 10):
        m = f'm1.random.{i}'
        if m not in data_frame.columns:
            continue
        if m in data_frame.columns:
            if i == 1:
                prev_m = 'm0'
                churn_list.append(calc_churn(data_frame, prev_m))
            else:
                prev_m = f'm1.random.{i-1}'
        churn_list.append(calc_churn(data_frame, m))
        nf_df = data_frame[(data_frame[prev_m]==truth)&(data_frame[m]!=truth)]
        nf_set = set()
        nf_set.update(nf_df.index.values.tolist())
        nf_list.append(nf_set)
    
    churn_all = set()
    for churn in churn_list:
        churn_all = churn_all | churn[0] | churn[1] | churn[2]
    nf_all = set()
    for nf in nf_list:
        nf_all = nf_all | nf
    
    nf_churn = churn_all & nf_all
    df.loc[exp.id, 'nf_churn'] = len(nf_churn)
    df.loc[exp.id, 'churn'] = len(churn_all)
    df.loc[exp.id, 'nf'] = len(nf_all)
    df.loc[exp.id, 'total'] = len(data_frame)

def plot_clever(clever_map):
    fig = go.Figure()
    nf_x = []
    nf_y = []
    all_right_x = []
    all_right_y = []
    for key in sorted(clever_map.keys(), key=cmp_to_key(keys_cmp)):
        id, step, type = key
        id = id.split('.')
        ds = fixup_map[id[0]]
        model = fixup_map[id[1]]
        y = clever_map[key]
        x = len(y)*[f'{ds}/{model} step:{step}']
        if type == 'nf_1':
            nf_y.extend(y)
            nf_x.extend(x)
        elif type == 'all_right_1':
            all_right_y.extend(y)
            all_right_x.extend(x)

    fig.add_trace(go.Box(
        y=nf_y,
        x=nf_x,
        quartilemethod="linear",
        boxpoints=False,
        name='with regression',
        showlegend=True
        )
    )
    fig.add_trace(go.Box(
        y=all_right_y,
        x=all_right_x,
        quartilemethod="linear",
        boxpoints=False,
        name='w/o regression',
        showlegend=True
        )
    )
    fig.update_layout(
        yaxis_title='CLEVER score',
        boxmode='group' # group together boxes of the different traces for each value of x
    )
    # fig.show()
    return fig

fixup_map = {
    'MNIST': 'MNIST',
    'FashionMNIST': 'Fashion-MNIST',
    'SVHN': 'SVHN',
    'CIFAR10': 'CIFAR-10',
    'LeNet1': 'LeNet-1',
    'LeNet5': 'LeNet-5',
    'resnet18': 'ResNet-18'
}

ds_seq = ['MNIST', 'Fashion-MNIST', 'SVHN', 'CIFAR-10']
mod_seq = ['LeNet-1', 'LeNet-5', 'ResNet-18']

def keys_cmp(x, y):
    x_id, x_step, x_type = x
    y_id, y_step, y_type = y
    xx = x_id.split('.')
    yy = y_id.split('.')
    x_ds = fixup_map[xx[0]]
    x_model = fixup_map[xx[1]]
    y_ds = fixup_map[yy[0]]
    y_model = fixup_map[yy[1]]
    if x_ds != y_ds:
        return ds_seq.index(x_ds) - ds_seq.index(y_ds)
    if x_model != y_model:
        return mod_seq.index(x_model) - mod_seq.index(y_model)
    return x_step - y_step