import torch
from art.attacks.evasion import FastGradientMethod
from art.attacks.evasion.iterative_method import BasicIterativeMethod
from art.attacks.evasion.saliency_map import SaliencyMapMethod
from art.attacks.evasion.carlini import CarliniL2Method, CarliniLInfMethod
from art.estimators.classification import PyTorchClassifier
__all__ = ['FGSM', 'BIM', 'CW', 'JSMA']

def _art_attack(clz, model, num_classes, images, labels, **kwargs):
    input_shape=images.shape[1:]
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9, weight_decay=1.e-6, nesterov=True)
    criterion = torch.nn.CrossEntropyLoss()
    classifier = PyTorchClassifier(
        model=model,
        loss=criterion,
        input_shape=input_shape,
        nb_classes=num_classes,
        optimizer=optimizer
    )
    attack = clz(classifier, **kwargs)
    adv_examples = attack.generate(x=images, y=labels)
    return torch.from_numpy(adv_examples)

def FGSM(model, num_classes, images, labels, **kwargs):
    return _art_attack(FastGradientMethod, model, num_classes, images, labels, **kwargs)

def BIM(model, num_classes, images, labels, **kwargs):
    return _art_attack(BasicIterativeMethod, model, num_classes, images, labels, **kwargs)

def CW(model, num_classes, images, labels, **kwargs):
    return _art_attack(CarliniL2Method, model, num_classes, images, labels, **kwargs)

def JSMA(model, num_classes, images, labels, **kwargs):
    return _art_attack(SaliencyMapMethod, model, num_classes, images, labels, **kwargs)