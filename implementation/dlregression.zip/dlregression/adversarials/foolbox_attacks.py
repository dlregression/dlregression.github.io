import torch
import foolbox
from foolbox import PyTorchModel

__all__ = ['FGSM', 'BIM', 'CW', 'DeepFool']

def _foolbox_attack(attack, model, images, labels, **kwargs):
    fmodel = PyTorchModel(model, bounds=(0,255))
    raw_advs, clipped_advs, success = attack(fmodel, images, labels, **kwargs)
    return torch.cat(clipped_advs)

def FGSM(model, num_classes, images, labels, **kwargs):
    return _foolbox_attack(foolbox.attacks.FGSM(), model, images, labels, **kwargs)

def BIM(model, num_classes, images, labels, **kwargs):
    return _foolbox_attack(foolbox.attacks.L2BasicIterativeAttack(), model, images, labels, **kwargs)

def CW(model, num_classes, images, labels, **kwargs):
    return _foolbox_attack(foolbox.attacks.L2CarliniWagnerAttack(), model, images, labels, **kwargs)

def DeepFool(model, num_classes, images, labels, **kwargs):
    return _foolbox_attack(foolbox.attacks.L2DeepFoolAttack(), model, images, labels, **kwargs)